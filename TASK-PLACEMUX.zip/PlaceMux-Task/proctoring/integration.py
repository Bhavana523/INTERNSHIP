
import time
import math
from dataclasses import dataclass, field, asdict
from typing import Optional
import sys, os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from Irt_calibration import IRTCalibration, p3pl
from Catengine import (
    CATEngine, InferenceEndpoint, AssessmentSession,
    SEM_STOP_THRESHOLD, MAX_ITEMS, MIN_ITEMS,
    theta_to_scaled_score, score_to_performance_band,
)
from proctoring.proctoring_engine import (
    ProctoringEngine,
    ViolationType,
    Severity,
    RISK_PASS_MAX,
    RISK_WARNING_MAX,
)

REVIEW_LOWER_RISK = 0.45
REVIEW_UPPER_RISK = 0.70
RECALIBRATION_RESPONSE_THRESHOLD = 30



@dataclass
class SignalBundle:
    
    student_id: str
    assessment_id: str
    vision_risk: float = 0.0
    audio_risk: float = 0.0
    behavioral_risk: float = 0.0
    violations: list = field(default_factory=list)
    flag_report: list = field(default_factory=list)

    def to_dict(self):
        return asdict(self)


@dataclass
class IntegrityVerdict:
    
    student_id: str
    assessment_id: str
    integrity_status: str
    risk_score: float
    route_to_review: bool
    violations: list
    flag_report: list
    auto_terminated: bool
    action: str
    generated_at: float = field(default_factory=time.time)

    def to_dict(self):
        d = asdict(self)
        d["generated_at_iso"] = time.strftime(
            "%Y-%m-%dT%H:%M:%SZ", time.gmtime(self.generated_at)
        )
        return d



class SignalFuser:
    
    WEIGHTS = {"vision": 0.55, "behavioral": 0.30, "audio": 0.15}

    def fuse(self, bundle: SignalBundle) -> float:
        return round(min(1.0, (
            self.WEIGHTS["vision"]     * bundle.vision_risk +
            self.WEIGHTS["behavioral"] * bundle.behavioral_risk +
            self.WEIGHTS["audio"]      * bundle.audio_risk
        )), 4)



class FlagAggregator:
    

    def aggregate(self, proctoring_report: dict,
                  behavioral_events: list) -> list:
        seen = {}

        for v in proctoring_report.get("violations", []):
            vtype = v.get("type") or v.get("violation_type", "UNKNOWN")
            if vtype not in seen:
                seen[vtype] = {
                    "violation_type": vtype,
                    "severity": v.get("severity", "MEDIUM"),
                    "count": v.get("count", 1),
                    "source": v.get("source", "vision"),
                    "first_occurrence": time.time(),
                }
            else:
                seen[vtype]["count"] += 1

        behavioral_map = {
            "tab_switch":        ("TAB_SWITCHING", "MEDIUM"),
            "browser_minimize":  ("BROWSER_MINIMIZED", "LOW"),
            "external_device":   ("EXTERNAL_DEVICE_DETECTED", "HIGH"),
            "fullscreen_exit":   ("FULLSCREEN_EXIT", "MEDIUM"),
            "copy_attempt":      ("COPY_ATTEMPT", "HIGH"),
            "paste_attempt":     ("PASTE_ATTEMPT", "HIGH"),
        }
        for event in behavioral_events:
            raw_type = event.get("type", "").lower()
            e_type, severity = behavioral_map.get(raw_type, (raw_type.upper(), "LOW"))
            if e_type not in seen:
                seen[e_type] = {
                    "violation_type": e_type,
                    "severity": severity,
                    "count": 1,
                    "source": "behavioral",
                    "first_occurrence": event.get("timestamp", time.time()),
                }
            else:
                seen[e_type]["count"] += 1

        severity_order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}
        return sorted(seen.values(),
                       key=lambda f: severity_order.get(f["severity"], 99))



class IntegrityReporter:
    

    def generate_verdict(self,
                          student_id: str,
                          assessment_id: str,
                          fused_risk: float,
                          flag_report: list,
                          proctoring_report: dict) -> IntegrityVerdict:
        auto_terminated = proctoring_report.get("auto_terminated", False)
        violations = proctoring_report.get("violations", [])

        if auto_terminated or fused_risk > REVIEW_UPPER_RISK:
            status = "FAIL"
            route_to_review = False
            action = "SUBMIT_AND_TERMINATE"
        elif fused_risk > REVIEW_LOWER_RISK:
            status = "WARNING"
            route_to_review = True
            action = "ROUTE_TO_REVIEW"
        elif fused_risk > RISK_PASS_MAX:
            status = "WARNING"
            route_to_review = False
            action = "SHOW_WARNING"
        else:
            status = "PASS"
            route_to_review = False
            action = "NONE"

        return IntegrityVerdict(
            student_id=student_id,
            assessment_id=assessment_id,
            integrity_status=status,
            risk_score=fused_risk,
            route_to_review=route_to_review,
            violations=violations,
            flag_report=flag_report,
            auto_terminated=auto_terminated,
            action=action,
        )



class RecalibrationPipeline:

    def __init__(self, calibration: IRTCalibration):
        self.calibration = calibration
        self._response_store: dict = {}
        self.calibration_log: list = []

    def ingest_response(self, item_id: str, response: int, theta_estimate: float):
        if item_id not in self._response_store:
            self._response_store[item_id] = []
        self._response_store[item_id].append((theta_estimate, response))

    def run_scheduled_recalibration(self) -> dict:
        import numpy as np
        updated, skipped = [], []
        for item_id, records in self._response_store.items():
            if len(records) < RECALIBRATION_RESPONSE_THRESHOLD:
                skipped.append({"item_id": item_id, "response_count": len(records)})
                continue
            responses = np.array([r[1] for r in records])
            thetas = np.array([r[0] for r in records])
            old = self.calibration.get_params(item_id)
            new = self.calibration.update_empirical(item_id, responses, thetas)
            if new["source"] == "EMPIRICAL":
                updated.append({"item_id": item_id, "old": old, "new": new})
        return {"items_updated": len(updated), "items_skipped": len(skipped),
                "updated": updated}



class IntegratedPipeline:

    def __init__(self, cat_endpoint: InferenceEndpoint,
                 proctoring_engine: ProctoringEngine):
        self.cat = cat_endpoint
        self.proctoring = proctoring_engine
        self.fuser = SignalFuser()
        self.aggregator = FlagAggregator()
        self.reporter = IntegrityReporter()

    def run_full_session(self, student_id, assessment_id, competency_id,
                          registered_photo, live_photo,
                          behavioral_events, frame_scenarios,
                          true_theta=0.5) -> dict:
        import numpy as np

        self.proctoring.start_session(student_id, assessment_id,
                                       registered_photo, live_photo)

        req = {"student_id": student_id, "assessment_id": assessment_id,
               "current_competency_id": competency_id,
               "current_ability_estimate": 0.0}
        rng = np.random.default_rng(42)

        for turn in range(MAX_ITEMS + 1):
            scenario = frame_scenarios[turn] if turn < len(frame_scenarios) else "clean"
            self.proctoring.process_frame(student_id, assessment_id,
                                           f"FRAME_{turn}".encode(), inject_scenario=scenario)
            r = self.cat.next_item(req)
            if r["stop_test"]:
                break
            iid = r["next_item_id"]
            from Irt_calibration import p3pl
            cal = self.cat.engine.calibration
            params = cal.get_params(iid)
            prob = p3pl(true_theta, params["a"], params["b"], params["c"]) if params else 0.5
            resp = int(rng.random() < prob)
            state = self.cat.submit_response(student_id, assessment_id,
                                              competency_id, iid, resp)
            req["current_ability_estimate"] = state["theta"]

        for event in behavioral_events:
            self.proctoring.ingest_behavioral_event(
                student_id, assessment_id, event["type"]
            )

        cat_final = self.cat.get_final_score(student_id, assessment_id, competency_id)
        proc_report = self.proctoring.get_integrity_report(student_id, assessment_id)

        bundle = SignalBundle(
            student_id=student_id, assessment_id=assessment_id,
            vision_risk=proc_report.get("risk_score", 0.0),
            audio_risk=0.05,
            behavioral_risk=min(1.0, len(behavioral_events) * 0.15),
        )
        fused_risk = self.fuser.fuse(bundle)
        flags = self.aggregator.aggregate(proc_report, behavioral_events)
        verdict = self.reporter.generate_verdict(
            student_id, assessment_id, fused_risk, flags, proc_report
        )

        return {"cat_result": cat_final, "proctoring_report": proc_report,
                "integrity_verdict": verdict.to_dict(), "signal_bundle": bundle.to_dict()}