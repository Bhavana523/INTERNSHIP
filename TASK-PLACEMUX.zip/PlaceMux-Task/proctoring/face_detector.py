
import cv2
import numpy as np
import time
from dataclasses import dataclass, field
from typing import Optional



def _get_cascade(name: str) -> cv2.CascadeClassifier:
    
    path = cv2.data.haarcascades + name
    cascade = cv2.CascadeClassifier(path)
    if cascade.empty():
        raise FileNotFoundError(f"Cascade not found: {path}")
    return cascade


_FACE_CASCADE: Optional[cv2.CascadeClassifier] = None
_EYE_CASCADE: Optional[cv2.CascadeClassifier] = None


def _face_cascade() -> cv2.CascadeClassifier:
    global _FACE_CASCADE
    if _FACE_CASCADE is None:
        _FACE_CASCADE = _get_cascade("haarcascade_frontalface_default.xml")
    return _FACE_CASCADE


def _eye_cascade() -> cv2.CascadeClassifier:
    global _EYE_CASCADE
    if _EYE_CASCADE is None:
        _EYE_CASCADE = _get_cascade("haarcascade_eye.xml")
    return _EYE_CASCADE



@dataclass
class FaceBox:
    
    x: int
    y: int
    w: int
    h: int
    confidence: float = 1.0

    @property
    def center(self):
        return (self.x + self.w // 2, self.y + self.h // 2)

    @property
    def area(self):
        return self.w * self.h

    def to_dict(self) -> dict:
        return {"x": self.x, "y": self.y, "w": self.w, "h": self.h,
                "confidence": self.confidence}


@dataclass
class HeadPose:
    
    yaw: float = 0.0       
    pitch: float = 0.0     
    is_frontal: bool = True
    gaze_direction: str = "FORWARD"  

    def to_dict(self) -> dict:
        return {"yaw": self.yaw, "pitch": self.pitch,
                "is_frontal": self.is_frontal,
                "gaze_direction": self.gaze_direction}


@dataclass
class FaceDetectionResult:
    
    timestamp: float = field(default_factory=time.time)
    frame_id: int = 0
    face_count: int = 0
    faces: list = field(default_factory=list)       
    primary_face: Optional[FaceBox] = None
    head_pose: Optional[HeadPose] = None
    eyes_detected: bool = False
    image_quality: str = "GOOD"   
    processing_ms: float = 0.0

    @property
    def has_face(self) -> bool:
        return self.face_count > 0

    @property
    def multiple_faces(self) -> bool:
        return self.face_count > 1

    @property
    def head_turned(self) -> bool:
        if self.head_pose is None:
            return False
        return not self.head_pose.is_frontal

    def to_dict(self) -> dict:
        return {
            "timestamp": self.timestamp,
            "frame_id": self.frame_id,
            "face_count": self.face_count,
            "has_face": self.has_face,
            "multiple_faces": self.multiple_faces,
            "head_turned": self.head_turned,
            "eyes_detected": self.eyes_detected,
            "image_quality": self.image_quality,
            "head_pose": self.head_pose.to_dict() if self.head_pose else None,
            "primary_face": self.primary_face.to_dict() if self.primary_face else None,
            "processing_ms": round(self.processing_ms, 2),
        }



def _check_image_quality(gray: np.ndarray) -> str:
    
    mean_brightness = float(np.mean(gray))
    laplacian_var = float(cv2.Laplacian(gray, cv2.CV_64F).var())

    if mean_brightness < 40:
        return "DARK"
    if laplacian_var < 50:
        return "BLURRY"
    return "GOOD"



def _estimate_head_pose(gray: np.ndarray, face: FaceBox) -> HeadPose:
    
    eye_casc = _eye_cascade()
    roi = gray[face.y:face.y + face.h, face.x:face.x + face.w]
    eyes = eye_casc.detectMultiScale(roi, scaleFactor=1.1, minNeighbors=3,
                                      minSize=(15, 15))

    if len(eyes) == 0:
        
        return HeadPose(yaw=0.8, pitch=0.0, is_frontal=False,
                        gaze_direction="AWAY")

    if len(eyes) == 1:
        
        ex, ey, ew, eh = eyes[0]
        eye_cx = ex + ew // 2
        face_cx = face.w // 2
        offset = (eye_cx - face_cx) / max(face.w, 1)
        direction = "LEFT" if offset < -0.15 else "RIGHT" if offset > 0.15 else "FORWARD"
        yaw = abs(offset)
        return HeadPose(yaw=yaw, pitch=0.0,
                        is_frontal=(yaw < 0.25), gaze_direction=direction)

    
    eye_centers = [(ex + ew // 2, ey + eh // 2) for ex, ey, ew, eh in eyes[:2]]
    mid_x = (eye_centers[0][0] + eye_centers[1][0]) / 2
    face_cx = face.w / 2
    lateral_offset = (mid_x - face_cx) / max(face.w, 1)
    yaw = abs(lateral_offset)

    
    mid_y = (eye_centers[0][1] + eye_centers[1][1]) / 2
    vertical_offset = mid_y / max(face.h, 1) - 0.35  
    pitch = vertical_offset

    is_frontal = yaw < 0.20 and abs(pitch) < 0.15

    if lateral_offset < -0.20:
        direction = "LEFT"
    elif lateral_offset > 0.20:
        direction = "RIGHT"
    elif pitch > 0.15:
        direction = "DOWN"
    elif pitch < -0.15:
        direction = "UP"
    else:
        direction = "FORWARD"

    return HeadPose(yaw=yaw, pitch=pitch, is_frontal=is_frontal,
                    gaze_direction=direction)



class FaceDetector:
    

    HAAR_SCALE = 1.1
    HAAR_MIN_NEIGHBORS = 3
    HAAR_MIN_SIZE = (30, 30)

    def __init__(self):
        self._frame_hashes: list = []       
        self._hash_window = 5               
        self._frame_counter = 0

    def detect(self, frame_input, frame_id: int = None) -> FaceDetectionResult:
        
        t_start = time.time()
        self._frame_counter += 1
        fid = frame_id if frame_id is not None else self._frame_counter

        result = FaceDetectionResult(frame_id=fid)

        
        try:
            if isinstance(frame_input, bytes):
                arr = np.frombuffer(frame_input, np.uint8)
                frame = cv2.imdecode(arr, cv2.IMREAD_COLOR)
            elif hasattr(frame_input, "read"):
                
                raw = frame_input.read()
                arr = np.frombuffer(raw, np.uint8)
                frame = cv2.imdecode(arr, cv2.IMREAD_COLOR)
            elif isinstance(frame_input, np.ndarray):
                frame = frame_input
            else:
                result.image_quality = "DECODE_FAILED"
                return result

            if frame is None or frame.size == 0:
                result.image_quality = "DECODE_FAILED"
                return result

        except Exception:
            result.image_quality = "DECODE_FAILED"
            return result

        
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        gray = cv2.equalizeHist(gray)   

        result.image_quality = _check_image_quality(gray)

        frame_hash = int(np.sum(gray[::8, ::8]))  # Cheap spatial hash
        self._frame_hashes.append(frame_hash)
        if len(self._frame_hashes) > self._hash_window:
            self._frame_hashes.pop(0)
        if len(self._frame_hashes) >= 3:
            unique = len(set(self._frame_hashes[-3:]))
            if unique == 1:
                result.image_quality = "FROZEN"

        h_frame, w_frame = gray.shape[:2]
        raw_faces = _face_cascade().detectMultiScale(
            gray,
            scaleFactor=self.HAAR_SCALE,
            minNeighbors=self.HAAR_MIN_NEIGHBORS,
            minSize=self.HAAR_MIN_SIZE,
            flags=cv2.CASCADE_SCALE_IMAGE,
        )

        if len(raw_faces) == 0:
            result.face_count = 0
            result.processing_ms = (time.time() - t_start) * 1000
            return result

        face_boxes = sorted(
            [FaceBox(x=int(x), y=int(y), w=int(w), h=int(h))
             for x, y, w, h in raw_faces],
            key=lambda f: f.area,
            reverse=True,
        )

        result.face_count = len(face_boxes)
        print("DETECTED FACES:", len(face_boxes))
        result.faces = face_boxes
        result.primary_face = face_boxes[0]

        result.head_pose = _estimate_head_pose(gray, result.primary_face)

        eye_casc = _eye_cascade()
        roi = gray[result.primary_face.y:result.primary_face.y + result.primary_face.h,
                   result.primary_face.x:result.primary_face.x + result.primary_face.w]
        eyes = eye_casc.detectMultiScale(roi, 1.1, 3, minSize=(15, 15))
        result.eyes_detected = len(eyes) >= 1

        result.processing_ms = (time.time() - t_start) * 1000
        return result

    def annotate_frame(self, frame_input, result: FaceDetectionResult) -> Optional[np.ndarray]:
       
        try:
            if isinstance(frame_input, bytes):
                arr = np.frombuffer(frame_input, np.uint8)
                frame = cv2.imdecode(arr, cv2.IMREAD_COLOR)
            elif hasattr(frame_input, "read"):
                raw = frame_input.read()
                arr = np.frombuffer(raw, np.uint8)
                frame = cv2.imdecode(arr, cv2.IMREAD_COLOR)
            else:
                frame = frame_input.copy()

            if frame is None:
                return None

            for i, face in enumerate(result.faces):
                color = (0, 255, 0) if i == 0 else (0, 0, 255)
                cv2.rectangle(frame, (face.x, face.y),
                              (face.x + face.w, face.y + face.h), color, 2)
                label = "PRIMARY" if i == 0 else f"EXTRA FACE {i}"
                cv2.putText(frame, label, (face.x, face.y - 8),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.55, color, 2)

            if result.head_pose:
                direction = result.head_pose.gaze_direction
                color = (0, 255, 0) if direction == "FORWARD" else (0, 165, 255)
                cv2.putText(frame, f"Gaze: {direction}", (10, 30),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)

            cv2.putText(frame, f"Faces: {result.face_count}", (10, 60),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 1)
            cv2.putText(frame, f"Quality: {result.image_quality}", (10, 85),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (200, 200, 200), 1)

            return frame

        except Exception:
            return None