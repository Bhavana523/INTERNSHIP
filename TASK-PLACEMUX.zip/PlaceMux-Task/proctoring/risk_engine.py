

import time
from dataclasses import dataclass, field
from typing import Optional

from .face_detector import FaceDetectionResult



VISION_WEIGHTS = {
    "NO_FACE":              0.25,
    "MULTIPLE_FACES":       0.35,
    "HEAD_TURNED":          0.10,
    "EYES_CLOSED":          0.08,
    "DARK_FRAME":           0.05,
    "BLURRY_FRAME":         0.05,
    "FROZEN_FRAME":         0.15,
    "IDENTITY_MISMATCH":    0.90,
}

BEHAVIORAL_WEIGHTS = {
    "TAB_SWITCH":           0.15,
    "BROWSER_MINIMIZE":     0.10,
    "FULLSCREEN_EXIT":      0.20,
    "FOCUS_LOSS":           0.12,
    "COPY_ATTEMPT":         0.20,
    "PASTE_ATTEMPT":        0.25,
    "EXTERNAL_DEVICE":      0.35,
    "MULTIPLE_MONITOR":     0.30,
    "KEYBOARD_SHORTCUT":    0.15,
}

FUSION_WEIGHTS = {
    "vision":     0.55,
    "behavioral": 0.30,
    "audio":      0.15,
}

PASS_MAX       = 0.30
WARNING_MAX    = 0.70
REVIEW_MIN     = 0.45   

AUTO_TERMINATE_WARNINGS = 3



@dataclass
class ViolationEvent:
    source: str            
    violation_type: str
    severity: str          
    risk_weight: float
    timestamp: float
    detail: str = ""
    frame_id: Optional[int] = None

    def to_dict(self) -> dict:
        return {
            "source": self.source,
            "violation_type": self.violation_type,
            "severity": self.severity,
            "risk_weight": self.risk_weight,
            "timestamp": self.timestamp,
            "timestamp_str": time.strftime("%H:%M:%S", time.localtime(self.timestamp)),
            "detail": self.detail,
            "frame_id": self.frame_id,
        }


@dataclass
class RiskState:
    vision_risk: float = 0.0
    behavioral_risk: float = 0.0
    audio_risk: float = 0.05     
    fused_risk: float = 0.0
    integrity_status: str = "PASS"
    action: str = "NONE"
    warning_count: int = 0
    auto_terminated: bool = False
    total_violations: int = 0
    violations: list = field(default_factory=list)   

    def to_dict(self) -> dict:
        return {
            "vision_risk": round(self.vision_risk, 4),
            "behavioral_risk": round(self.behavioral_risk, 4),
            "audio_risk": round(self.audio_risk, 4),
            "fused_risk": round(self.fused_risk, 4),
            "integrity_status": self.integrity_status,
            "action": self.action,
            "warning_count": self.warning_count,
            "auto_terminated": self.auto_terminated,
            "total_violations": self.total_violations,
        }



class RiskEngine:
    

    def __init__(self):
        self._state = RiskState()
        self._vision_type_counts: dict = {}
        self._behavioral_type_counts: dict = {}
        self._identity_verified: bool = False
        self._session_start = time.time()


    def process_frame(self, det: FaceDetectionResult,
                       frame_id: Optional[int] = None) -> RiskState:
        
        violations_this_frame = []

        if not det.has_face and det.image_quality not in ("DECODE_FAILED",):
            v = self._make_vision_violation("NO_FACE", det.frame_id,
                                             "No face detected in frame",
                                             severity="HIGH")
            violations_this_frame.append(v)

        if det.multiple_faces:
            v = self._make_vision_violation("MULTIPLE_FACES", det.frame_id,
                                             f"{det.face_count} faces detected",
                                             severity="HIGH")
            violations_this_frame.append(v)

        if det.has_face and det.head_turned:
            direction = det.head_pose.gaze_direction if det.head_pose else "UNKNOWN"
            v = self._make_vision_violation("HEAD_TURNED", det.frame_id,
                                             f"Gaze direction: {direction}",
                                             severity="MEDIUM")
            violations_this_frame.append(v)

        if det.image_quality == "DARK":
            v = self._make_vision_violation("DARK_FRAME", det.frame_id,
                                             "Frame too dark", severity="LOW")
            violations_this_frame.append(v)
        elif det.image_quality == "BLURRY":
            v = self._make_vision_violation("BLURRY_FRAME", det.frame_id,
                                             "Frame blurry", severity="LOW")
            violations_this_frame.append(v)
        elif det.image_quality == "FROZEN":
            v = self._make_vision_violation("FROZEN_FRAME", det.frame_id,
                                             "Camera appears frozen", severity="MEDIUM")
            violations_this_frame.append(v)

        self._state.violations.extend(violations_this_frame)
        self._state.total_violations += len(violations_this_frame)

        self._state.vision_risk = self._compute_vision_risk()

        self._fuse_and_update()
        return self._state

    def process_identity(self, verified: bool, similarity: float) -> RiskState:
        
        self._identity_verified = verified
        if not verified:
            v = ViolationEvent(
                source="vision",
                violation_type="IDENTITY_MISMATCH",
                severity="CRITICAL",
                risk_weight=VISION_WEIGHTS["IDENTITY_MISMATCH"],
                timestamp=time.time(),
                detail=f"Similarity: {similarity:.3f}",
            )
            self._state.violations.append(v)
            self._state.total_violations += 1
            self._state.vision_risk = min(1.0, self._state.vision_risk + 0.90)
        self._fuse_and_update()
        return self._state

    def process_behavioral(self, event_type: str, risk_weight: float,
                            detail: str = "") -> RiskState:
        
        v = ViolationEvent(
            source="behavioral",
            violation_type=event_type,
            severity=_behavioral_severity(event_type),
            risk_weight=risk_weight,
            timestamp=time.time(),
            detail=detail,
        )
        self._state.violations.append(v)
        self._state.total_violations += 1

        
        count = self._behavioral_type_counts.get(event_type, 0) + 1
        self._behavioral_type_counts[event_type] = count
        effective_weight = risk_weight if count == 1 else risk_weight * 0.6

        self._state.behavioral_risk = min(
            1.0, self._state.behavioral_risk + effective_weight
        )
        self._fuse_and_update()
        return self._state


    def _compute_vision_risk(self) -> float:
        
        if not self._vision_type_counts and not any(
            v.source == "vision" for v in self._state.violations
        ):
            return 0.0

        type_risks: dict = {}
        for v in self._state.violations:
            if v.source != "vision":
                continue
            base = VISION_WEIGHTS.get(v.violation_type, 0.05)
            count = type_risks.get(v.violation_type, {}).get("count", 0) + 1
            accumulated = type_risks.get(v.violation_type, {}).get("risk", 0)
            factors = [1.0, 0.60, 0.40, 0.25, 0.15]
            factor = factors[min(count - 1, len(factors) - 1)]
            type_risks[v.violation_type] = {
                "count": count,
                "risk": accumulated + base * factor,
            }

        total = sum(r["risk"] for r in type_risks.values())
        return min(1.0, total)

    def _fuse_and_update(self):
        fused = (
            FUSION_WEIGHTS["vision"]     * self._state.vision_risk +
            FUSION_WEIGHTS["behavioral"] * self._state.behavioral_risk +
            FUSION_WEIGHTS["audio"]      * self._state.audio_risk
        )
        self._state.fused_risk = round(min(1.0, fused), 4)

        if self._state.auto_terminated:
            self._state.integrity_status = "FAIL"
            self._state.action = "SUBMIT_AND_TERMINATE"
            return

        r = self._state.fused_risk
        if r <= PASS_MAX:
            self._state.integrity_status = "PASS"
            self._state.action = "NONE"
        elif r <= REVIEW_MIN:
            self._state.integrity_status = "WARNING"
            self._state.action = "SHOW_WARNING"
            self._state.warning_count += 1
        elif r <= WARNING_MAX:
            self._state.integrity_status = "WARNING"
            self._state.action = "ROUTE_TO_REVIEW"
            self._state.warning_count += 1
        else:
            self._state.integrity_status = "FAIL"
            self._state.action = "SUBMIT_AND_TERMINATE"

        if self._state.warning_count >= AUTO_TERMINATE_WARNINGS:
            self._state.auto_terminated = True
            self._state.integrity_status = "FAIL"
            self._state.action = "SUBMIT_AND_TERMINATE"


    def _make_vision_violation(self, vtype: str, frame_id, detail: str,
                                severity: str) -> ViolationEvent:
        count = self._vision_type_counts.get(vtype, 0) + 1
        self._vision_type_counts[vtype] = count
        return ViolationEvent(
            source="vision",
            violation_type=vtype,
            severity=severity,
            risk_weight=VISION_WEIGHTS.get(vtype, 0.05),
            timestamp=time.time(),
            detail=detail,
            frame_id=frame_id,
        )


    def get_state(self) -> RiskState:
        return self._state

    def generate_integrity_report(self,
                                   student_id: str,
                                   assessment_id: str,
                                   identity_score: float) -> dict:
        
        state = self._state
        
        seen = {}
        for v in state.violations:
            key = v.violation_type
            if key not in seen:
                seen[key] = {"type": v.violation_type, "severity": v.severity,
                              "source": v.source,
                              "count": 1}
            else:
                seen[key]["count"] += 1

        return {
            "student_id": student_id,
            "assessment_id": assessment_id,
            "integrity_status": state.integrity_status,
            "risk_score": round(state.fused_risk, 4),
            "vision_risk": round(state.vision_risk, 4),
            "behavioral_risk": round(state.behavioral_risk, 4),
            "audio_risk": round(state.audio_risk, 4),
            "violations": list(seen.values()),
            "violation_count": state.total_violations,
            "action": state.action,
            "warning_count": state.warning_count,
            "auto_terminated": state.auto_terminated,
            "identity_verified": self._identity_verified,
            "identity_score": round(identity_score, 4),
            "recommended_action": _recommend_action(state.integrity_status,
                                                     state.fused_risk),
            "generated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        }



def _behavioral_severity(event_type: str) -> str:
    HIGH = {"PASTE_ATTEMPT", "EXTERNAL_DEVICE", "MULTIPLE_MONITOR", "COPY_ATTEMPT"}
    MEDIUM = {"TAB_SWITCH", "FULLSCREEN_EXIT", "FOCUS_LOSS", "KEYBOARD_SHORTCUT"}
    if event_type in HIGH:
        return "HIGH"
    if event_type in MEDIUM:
        return "MEDIUM"
    return "LOW"


def _recommend_action(status: str, risk: float) -> str:
    if status == "PASS":
        return "No action required. Assessment integrity maintained."
    elif status == "WARNING" and risk <= 0.45:
        return "Issue warning to student. Continue monitoring."
    elif status == "WARNING":
        return "Route to human reviewer. Do not auto-fail."
    elif status == "FAIL":
        return "Terminate session. Flag for administrator review."
    return "Monitor closely."