
import time
from dataclasses import dataclass, field
from typing import Optional
from enum import Enum



class BehaviorEventType(str, Enum):
    TAB_SWITCH          = "TAB_SWITCH"
    BROWSER_MINIMIZE    = "BROWSER_MINIMIZE"
    FULLSCREEN_EXIT     = "FULLSCREEN_EXIT"
    FOCUS_LOSS          = "FOCUS_LOSS"
    COPY_ATTEMPT        = "COPY_ATTEMPT"
    PASTE_ATTEMPT       = "PASTE_ATTEMPT"
    EXTERNAL_DEVICE     = "EXTERNAL_DEVICE"
    MULTIPLE_MONITOR    = "MULTIPLE_MONITOR"
    KEYBOARD_SHORTCUT   = "KEYBOARD_SHORTCUT"  
    RAPID_NAVIGATION    = "RAPID_NAVIGATION"    


EVENT_RISK_WEIGHTS = {
    BehaviorEventType.TAB_SWITCH:        0.15,
    BehaviorEventType.BROWSER_MINIMIZE:  0.10,
    BehaviorEventType.FULLSCREEN_EXIT:   0.20,
    BehaviorEventType.FOCUS_LOSS:        0.12,
    BehaviorEventType.COPY_ATTEMPT:      0.20,
    BehaviorEventType.PASTE_ATTEMPT:     0.25,
    BehaviorEventType.EXTERNAL_DEVICE:   0.35,
    BehaviorEventType.MULTIPLE_MONITOR:  0.30,
    BehaviorEventType.KEYBOARD_SHORTCUT: 0.15,
    BehaviorEventType.RAPID_NAVIGATION:  0.10,
}

EVENT_SEVERITY = {
    BehaviorEventType.TAB_SWITCH:        "MEDIUM",
    BehaviorEventType.BROWSER_MINIMIZE:  "LOW",
    BehaviorEventType.FULLSCREEN_EXIT:   "MEDIUM",
    BehaviorEventType.FOCUS_LOSS:        "LOW",
    BehaviorEventType.COPY_ATTEMPT:      "HIGH",
    BehaviorEventType.PASTE_ATTEMPT:     "HIGH",
    BehaviorEventType.EXTERNAL_DEVICE:   "HIGH",
    BehaviorEventType.MULTIPLE_MONITOR:  "HIGH",
    BehaviorEventType.KEYBOARD_SHORTCUT: "MEDIUM",
    BehaviorEventType.RAPID_NAVIGATION:  "LOW",
}

STRING_TO_EVENT = {
    "tab_switch":        BehaviorEventType.TAB_SWITCH,
    "browser_minimize":  BehaviorEventType.BROWSER_MINIMIZE,
    "fullscreen_exit":   BehaviorEventType.FULLSCREEN_EXIT,
    "focus_loss":        BehaviorEventType.FOCUS_LOSS,
    "copy_attempt":      BehaviorEventType.COPY_ATTEMPT,
    "paste_attempt":     BehaviorEventType.PASTE_ATTEMPT,
    "external_device":   BehaviorEventType.EXTERNAL_DEVICE,
    "multiple_monitor":  BehaviorEventType.MULTIPLE_MONITOR,
    "keyboard_shortcut": BehaviorEventType.KEYBOARD_SHORTCUT,
    "rapid_navigation":  BehaviorEventType.RAPID_NAVIGATION,
}



@dataclass
class BehaviorEvent:
    event_type: str
    timestamp: float
    severity: str
    risk_weight: float
    detail: str = ""
    session_elapsed_s: float = 0.0

    def to_dict(self) -> dict:
        return {
            "event_type": self.event_type,
            "timestamp": self.timestamp,
            "timestamp_str": time.strftime("%H:%M:%S", time.localtime(self.timestamp)),
            "severity": self.severity,
            "risk_weight": self.risk_weight,
            "detail": self.detail,
            "session_elapsed_s": round(self.session_elapsed_s, 1),
        }


@dataclass
class BehaviorSummary:
    
    total_events: int = 0
    total_risk_contribution: float = 0.0
    event_type_counts: dict = field(default_factory=dict)
    high_severity_count: int = 0
    medium_severity_count: int = 0
    low_severity_count: int = 0
    events: list = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "total_events": self.total_events,
            "total_risk_contribution": round(self.total_risk_contribution, 4),
            "event_type_counts": self.event_type_counts,
            "high_severity_count": self.high_severity_count,
            "medium_severity_count": self.medium_severity_count,
            "low_severity_count": self.low_severity_count,
        }



class BehaviorMonitor:
    

    DEDUP_WINDOW_S = 2.0    

    def __init__(self):
        self._events: list = []
        self._session_start = time.time()
        self._last_event_time: dict = {}   

    def ingest(self, event_type_str: str, detail: str = "") -> Optional[BehaviorEvent]:
        
        now = time.time()

        
        evt_enum = STRING_TO_EVENT.get(event_type_str.lower())
        if evt_enum is None:
            
            evt_type = event_type_str.upper()
            risk_weight = 0.05
            severity = "LOW"
        else:
            evt_type = evt_enum.value
            risk_weight = EVENT_RISK_WEIGHTS.get(evt_enum, 0.05)
            severity = EVENT_SEVERITY.get(evt_enum, "LOW")

        
        last = self._last_event_time.get(evt_type, 0)
        if now - last < self.DEDUP_WINDOW_S:
            return None  
        self._last_event_time[evt_type] = now
        elapsed = now - self._session_start

        event = BehaviorEvent(
            event_type=evt_type,
            timestamp=now,
            severity=severity,
            risk_weight=risk_weight,
            detail=detail,
            session_elapsed_s=elapsed,
        )
        self._events.append(event)
        return event

    def get_summary(self) -> BehaviorSummary:
        
        summary = BehaviorSummary()
        summary.events = self._events.copy()
        summary.total_events = len(self._events)

        type_risk: dict = {}   

        for evt in self._events:
            
            summary.event_type_counts[evt.event_type] = \
                summary.event_type_counts.get(evt.event_type, 0) + 1

           
            if evt.severity == "HIGH":
                summary.high_severity_count += 1
            elif evt.severity == "MEDIUM":
                summary.medium_severity_count += 1
            else:
                summary.low_severity_count += 1

            
            count = summary.event_type_counts[evt.event_type]
            weight = evt.risk_weight * (1.0 if count == 1 else 0.6)
            type_risk[evt.event_type] = type_risk.get(evt.event_type, 0) + weight

        summary.total_risk_contribution = min(1.0, sum(type_risk.values()))
        return summary

    def get_events_list(self) -> list:
        
        return [e.to_dict() for e in self._events]

    def get_recent_events(self, n: int = 10) -> list:
        
        return [e.to_dict() for e in self._events[-n:]]

    def reset(self):
        
        self._events.clear()
        self._last_event_time.clear()
        self._session_start = time.time()



BEHAVIORAL_JS = """
<script>
// PlaceMux behavioral monitoring JavaScript
// Sends events to Streamlit via URL hash (polled by Streamlit component)

const PM_EVENTS = [];

function pmReport(eventType, detail) {
    const ts = Date.now();
    PM_EVENTS.push({type: eventType, detail: detail, ts: ts});
    // Store in sessionStorage so Streamlit can poll it
    sessionStorage.setItem('pm_events', JSON.stringify(PM_EVENTS.slice(-20)));
    console.log('[PlaceMux Proctoring]', eventType, detail);
}

// Tab switch / focus loss
document.addEventListener('visibilitychange', function() {
    if (document.hidden) {
        pmReport('tab_switch', 'Tab hidden at ' + new Date().toISOString());
    }
});

window.addEventListener('blur', function() {
    pmReport('focus_loss', 'Window lost focus');
});

// Fullscreen exit
document.addEventListener('fullscreenchange', function() {
    if (!document.fullscreenElement) {
        pmReport('fullscreen_exit', 'Exited fullscreen mode');
    }
});

// Copy/paste attempts
document.addEventListener('copy', function(e) {
    pmReport('copy_attempt', 'Content copied from exam page');
});

document.addEventListener('paste', function(e) {
    pmReport('paste_attempt', 'Paste attempted on exam page');
});

// Keyboard shortcuts (Dev tools, etc.)
document.addEventListener('keydown', function(e) {
    if (e.key === 'F12' || (e.ctrlKey && e.shiftKey && e.key === 'I') ||
        (e.ctrlKey && e.shiftKey && e.key === 'J')) {
        pmReport('keyboard_shortcut', 'Developer tools shortcut: ' + e.key);
        e.preventDefault();
    }
});

console.log('[PlaceMux] Behavioral monitoring active');
</script>
"""


def get_behavioral_js() -> str:
    
    return BEHAVIORAL_JS