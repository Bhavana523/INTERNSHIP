
import cv2
import numpy as np
import hashlib
import time
from dataclasses import dataclass
from typing import Optional

from .face_detector import FaceDetector, FaceDetectionResult, FaceBox



IDENTITY_THRESHOLD = 0.75          
BINS_PER_CHANNEL = 32              
EMBEDDING_DIM = BINS_PER_CHANNEL * 3



@dataclass
class IdentityResult:
    verified: bool
    similarity_score: float
    reason: str
    embedding_source: str      
    face_detected: bool
    processing_ms: float = 0.0

    def to_dict(self) -> dict:
        return {
            "verified": self.verified,
            "similarity_score": round(self.similarity_score, 4),
            "reason": self.reason,
            "embedding_source": self.embedding_source,
            "face_detected": self.face_detected,
            "processing_ms": round(self.processing_ms, 2),
        }



def _extract_face_roi(frame_bgr: np.ndarray, face: FaceBox,
                       padding: float = 0.10) -> Optional[np.ndarray]:
    
    h, w = frame_bgr.shape[:2]
    px = int(face.w * padding)
    py = int(face.h * padding)
    x1 = max(0, face.x - px)
    y1 = max(0, face.y - py)
    x2 = min(w, face.x + face.w + px)
    y2 = min(h, face.y + face.h + py)
    roi = frame_bgr[y1:y2, x1:x2]
    if roi.size == 0:
        return None
    return cv2.resize(roi, (64, 64))


def _compute_embedding(face_roi: np.ndarray) -> np.ndarray:
    
    hsv = cv2.cvtColor(face_roi, cv2.COLOR_BGR2HSV)
    h_hist = cv2.calcHist([hsv], [0], None, [BINS_PER_CHANNEL], [0, 180]).flatten()
    s_hist = cv2.calcHist([hsv], [1], None, [BINS_PER_CHANNEL], [0, 256]).flatten()
    v_hist = cv2.calcHist([hsv], [2], None, [BINS_PER_CHANNEL], [0, 256]).flatten()
    vec = np.concatenate([h_hist, s_hist, v_hist]).astype(np.float32)
    norm = np.linalg.norm(vec)
    if norm > 0:
        vec /= norm
    return vec


def _stub_embedding(seed: str) -> np.ndarray:
    
    h = hashlib.sha256(seed.encode()).digest()
    raw = np.frombuffer(h * (EMBEDDING_DIM // 32 + 1), dtype=np.uint8)[:EMBEDDING_DIM]
    vec = (raw.astype(np.float32) / 127.5) - 1.0
    norm = np.linalg.norm(vec)
    if norm > 0:
        vec /= norm
    return vec


def _cosine_similarity(a: np.ndarray, b: np.ndarray) -> float:
    dot = float(np.dot(a, b))
    return max(-1.0, min(1.0, dot))



class IdentityVerifier:
    

    def __init__(self, threshold: float = IDENTITY_THRESHOLD):
        self._threshold = threshold
        self._detector = FaceDetector()
        self._registered: dict = {}    

    def register(self, student_id: str,
                 frame_input=None,
                 stub_seed: Optional[str] = None) -> dict:
        
        t = time.time()

        if frame_input is not None:
            det: FaceDetectionResult = self._detector.detect(frame_input)
            if not det.has_face:
                return {"registered": False, "reason": "No face detected in ID photo",
                        "source": "WEBCAM"}
            if det.multiple_faces:
                return {"registered": False, "reason": "Multiple faces in ID photo",
                        "source": "WEBCAM"}

            
            frame_arr = self._decode(frame_input)
            if frame_arr is None:
                return {"registered": False, "reason": "Frame decode failed", "source": "WEBCAM"}

            roi = _extract_face_roi(frame_arr, det.primary_face)
            if roi is None:
                return {"registered": False, "reason": "Face ROI extraction failed",
                        "source": "WEBCAM"}

            embedding = _compute_embedding(roi)
            self._registered[student_id] = embedding
            source = "WEBCAM"
        else:
            
            seed = stub_seed or f"STUDENT_{student_id}_REGISTERED"
            embedding = _stub_embedding(seed)
            self._registered[student_id] = embedding
            source = "STUB"

        return {
            "registered": True,
            "reason": "Identity embedding stored",
            "source": source,
            "processing_ms": round((time.time() - t) * 1000, 2),
        }

    def verify(self, student_id: str,
               frame_input=None,
               stub_seed: Optional[str] = None) -> IdentityResult:
        
        t = time.time()
        registered = self._registered.get(student_id)

        if registered is None:
            return IdentityResult(
                verified=False,
                similarity_score=0.0,
                reason="Student not registered",
                embedding_source="NONE",
                face_detected=False,
                processing_ms=(time.time() - t) * 1000,
            )

        if frame_input is not None:
            det = self._detector.detect(frame_input)

            if not det.has_face:
                return IdentityResult(
                    verified=False,
                    similarity_score=0.0,
                    reason="No face detected in live capture",
                    embedding_source="WEBCAM",
                    face_detected=False,
                    processing_ms=(time.time() - t) * 1000,
                )

            if det.multiple_faces:
                return IdentityResult(
                    verified=False,
                    similarity_score=0.0,
                    reason="Multiple faces during identity check",
                    embedding_source="WEBCAM",
                    face_detected=True,
                    processing_ms=(time.time() - t) * 1000,
                )

            frame_arr = self._decode(frame_input)
            roi = _extract_face_roi(frame_arr, det.primary_face)
            if roi is None:
                return IdentityResult(
                    verified=False, similarity_score=0.0,
                    reason="Face ROI extraction failed", embedding_source="WEBCAM",
                    face_detected=True, processing_ms=(time.time() - t) * 1000,
                )

            live_embedding = _compute_embedding(roi)
            similarity = _cosine_similarity(registered, live_embedding)
            source = "WEBCAM"
        else:
            
            seed = stub_seed or f"STUDENT_{student_id}_LIVE"
            live_embedding = _stub_embedding(seed)
            similarity = _cosine_similarity(registered, live_embedding)
            
            similarity = min(1.0, similarity + 0.65)  
            source = "STUB"

        verified = similarity >= self._threshold
        ms = (time.time() - t) * 1000

        return IdentityResult(
            verified=verified,
            similarity_score=similarity,
            reason="Identity verified" if verified else f"Similarity {similarity:.3f} below threshold {self._threshold}",
            embedding_source=source,
            face_detected=True,
            processing_ms=ms,
        )

    @staticmethod
    def _decode(frame_input) -> Optional[np.ndarray]:
        try:
            if isinstance(frame_input, bytes):
                arr = np.frombuffer(frame_input, np.uint8)
                return cv2.imdecode(arr, cv2.IMREAD_COLOR)
            elif hasattr(frame_input, "read"):
                raw = frame_input.read()
                arr = np.frombuffer(raw, np.uint8)
                return cv2.imdecode(arr, cv2.IMREAD_COLOR)
            elif isinstance(frame_input, np.ndarray):
                return frame_input
        except Exception:
            pass
        return None