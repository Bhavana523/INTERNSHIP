
import time
import hashlib
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

from .face_detector import FaceDetector, FaceDetectionResult
from .identity_verifier import IdentityVerifier
from .behavior_monitor import (
    BehaviorMonitor,
    STRING_TO_EVENT,
    EVENT_RISK_WEIGHTS,
)
from .risk_engine import RiskEngine, RiskState



class ViolationType(str, Enum):
    MULTIPLE_FACE_DETECTED   = "MULTIPLE_FACE_DETECTED"
    NO_FACE_DETECTED         = "NO_FACE_DETECTED"
    TAB_SWITCHING            = "TAB_SWITCHING"
    BROWSER_MINIMIZED        = "BROWSER_MINIMIZED"
    SUSPICIOUS_HEAD_MOVEMENT = "SUSPICIOUS_HEAD_MOVEMENT"
    EXTERNAL_DEVICE_DETECTED = "EXTERNAL_DEVICE_DETECTED"
    IDENTITY_MISMATCH        = "IDENTITY_MISMATCH"
    FULLSCREEN_EXIT          = "FULLSCREEN_EXIT"
    FROZEN_CAMERA            = "FROZEN_CAMERA"
    DARK_FRAME               = "DARK_FRAME"


class Severity(str, Enum):
    LOW      = "LOW"
    MEDIUM   = "MEDIUM"
    HIGH     = "HIGH"
    CRITICAL = "CRITICAL"


RISK_PASS_MAX    = 0.30
RISK_WARNING_MAX = 0.70



@dataclass
class ProctoringSession:
    student_id: str
    assessment_id: str
    face_detector: FaceDetector = field(default_factory=FaceDetector)
    identity_verifier: IdentityVerifier = field(default_factory=IdentityVerifier)
    behavior_monitor: BehaviorMonitor = field(default_factory=BehaviorMonitor)
    risk_engine: RiskEngine = field(default_factory=RiskEngine)
    identity_score: float = 0.0
    frame_signals: list = field(default_factory=list)
    started_at: float = field(default_factory=time.time)



class ProctoringEngine:

    def __init__(self):
        self._sessions: dict = {}


    def start_session(self,
                       student_id: str,
                       assessment_id: str,
                       registered_photo=None,
                       live_photo=None) -> dict:
        
        key = f"{student_id}:{assessment_id}"
        session = ProctoringSession(
            student_id=student_id,
            assessment_id=assessment_id,
        )
        self._sessions[key] = session

        reg_result = session.identity_verifier.register(
            student_id=student_id,
            frame_input=registered_photo if _is_real_frame(registered_photo) else None,
            stub_seed=f"REGISTERED_{student_id}",
        )

        ver_result = session.identity_verifier.verify(
            student_id=student_id,
            frame_input=live_photo if _is_real_frame(live_photo) else None,
            stub_seed=f"REGISTERED_{student_id}",   
        )

        session.identity_score = ver_result.similarity_score
        session.risk_engine.process_identity(
            verified=ver_result.verified,
            similarity=ver_result.similarity_score,
        )

        return {
            "student_id": student_id,
            "assessment_id": assessment_id,
            "identity_verified": ver_result.verified,
            "match_score": round(ver_result.similarity_score, 4),
            "reason": ver_result.reason,
            "embedding_source": ver_result.embedding_source,
            "session_ready": True,
        }

    def process_frame(self,
                       student_id: str,
                       assessment_id: str,
                       frame_bytes=None,
                       inject_scenario: Optional[str] = None) -> dict:
        
        key = f"{student_id}:{assessment_id}"
        session = self._sessions.get(key)
        if session is None:
            return {"error": "Session not found"}

        state = session.risk_engine.get_state()
        if state.auto_terminated:
            return {"error": "Session auto-terminated", "auto_terminated": True}

        frame_n = len(session.frame_signals)

        
        if _is_real_frame(frame_bytes):
            
            det: FaceDetectionResult = session.face_detector.detect(frame_bytes, frame_id=frame_n)
        else:
            
            det = _synthetic_detection(inject_scenario or "clean", frame_n)

        
        state = session.risk_engine.process_frame(det, frame_id=frame_n)

        
        violations_this_frame = [
            v.violation_type for v in state.violations
            if getattr(v, "frame_id", None) == frame_n
        ]

        signal = {
            "frame_id": frame_n,
            "timestamp": time.time(),
            "face_count": det.face_count,
            "face_present": det.has_face,
            "head_turned": det.head_turned,
            "image_quality": det.image_quality,
            "violations_detected": violations_this_frame,
        }
        session.frame_signals.append(signal)

        action = state.action
        return {
            "frame_signal": signal,
            "risk_score": round(state.fused_risk, 4),
            "integrity_status": state.integrity_status,
            "warning_count": state.warning_count,
            "action": action,
            "auto_terminated": state.auto_terminated,
        }

    def ingest_behavioral_event(self,
                                 student_id: str,
                                 assessment_id: str,
                                 event_type: str,
                                 detail: str = "") -> dict:
        
        key = f"{student_id}:{assessment_id}"
        session = self._sessions.get(key)
        if session is None:
            return {"error": "Session not found"}

        event = session.behavior_monitor.ingest(event_type, detail)
        if event is None:
            
            state = session.risk_engine.get_state()
        else:
            
            weight = EVENT_RISK_WEIGHTS.get(
                STRING_TO_EVENT.get(event_type.lower()), 0.10
            )
            
            if hasattr(weight, 'value'):
                weight = 0.10
            state = session.risk_engine.process_behavioral(
                event_type.upper(), float(weight) if isinstance(weight, (int, float)) else 0.10, detail
            )

        return {
            "event_ingested": event_type,
            "risk_score": round(state.fused_risk, 4),
            "integrity_status": state.integrity_status,
            "action": state.action,
        }

    def get_integrity_report(self, student_id: str, assessment_id: str) -> dict:
        
        key = f"{student_id}:{assessment_id}"
        session = self._sessions.get(key)
        if session is None:
            return {"error": "Session not found"}

        return session.risk_engine.generate_integrity_report(
            student_id=student_id,
            assessment_id=assessment_id,
            identity_score=session.identity_score,
        )

    def get_latest_frame_result(self, student_id: str,
                                 assessment_id: str) -> Optional[dict]:
        
        key = f"{student_id}:{assessment_id}"
        session = self._sessions.get(key)
        if session is None or not session.frame_signals:
            return None
        return session.frame_signals[-1]



def _synthetic_detection(scenario: str, frame_id: int) -> FaceDetectionResult:
    
    from .face_detector import FaceBox, HeadPose

    if scenario == "no_face":
        return FaceDetectionResult(
            frame_id=frame_id,
            face_count=0,
            faces=[],
            primary_face=None,
            head_pose=None,
            eyes_detected=False,
            image_quality="GOOD",
        )

    elif scenario == "multiple_faces":
        face1 = FaceBox(x=50, y=50, w=100, h=100)
        face2 = FaceBox(x=250, y=50, w=90, h=90)
        return FaceDetectionResult(
            frame_id=frame_id,
            face_count=2,
            faces=[face1, face2],
            primary_face=face1,
            head_pose=HeadPose(yaw=0.05, pitch=0.0, is_frontal=True,
                               gaze_direction="FORWARD"),
            eyes_detected=True,
            image_quality="GOOD",
        )

    elif scenario == "head_movement":
        face = FaceBox(x=80, y=80, w=100, h=100)
        return FaceDetectionResult(
            frame_id=frame_id,
            face_count=1,
            faces=[face],
            primary_face=face,
            head_pose=HeadPose(yaw=0.45, pitch=0.05, is_frontal=False,
                               gaze_direction="LEFT"),
            eyes_detected=True,
            image_quality="GOOD",
        )

    else:  
        face = FaceBox(x=100, y=80, w=100, h=110)
        return FaceDetectionResult(
            frame_id=frame_id,
            face_count=1,
            faces=[face],
            primary_face=face,
            head_pose=HeadPose(yaw=0.05, pitch=0.0, is_frontal=True,
                               gaze_direction="FORWARD"),
            eyes_detected=True,
            image_quality="GOOD",
        )


def _is_real_frame(frame_input) -> bool:
    if frame_input is None:
        return False
    if isinstance(frame_input, bytes):
        if len(frame_input) < 200:
            try:
                frame_input.decode("ascii")
                return False   
            except Exception:
                pass
        return True   
    if hasattr(frame_input, "read"):
        return True   
    try:
        import numpy as np
        if isinstance(frame_input, np.ndarray):
            return True
    except ImportError:
        pass
    return False