import numpy as np
from scipy.optimize import minimize
from scipy.special import expit
import json


IRT_MODEL_RATIONALE = """
IRT Model Selection: 3PL

Selected model: Three-Parameter Logistic (3PL)
Rationale:
  1. Item types include MCQ (4-option) where random guessing probability ≈ 0.25.
     A 2PL model ignores this and over-estimates ability for low-ability test-takers
     who guess correctly. 3PL captures this via the c parameter.
  2. For Coding and Numeric items, guessing is negligible → c is fixed at 0.0,
     effectively making those items behave as 2PL.
  3. Discrimination parameter (a) is necessary because items vary significantly
     in how well they differentiate ability levels (SME-validated range: 0.9–1.9).
  4. Platform will eventually have large enough response volumes to empirically
     estimate all 3 parameters. Cold-start seeds from SME judgment minimise
     early-session bias.

Threshold for switching from SME seeds → empirical estimation: 30 responses/item.
"""

print(IRT_MODEL_RATIONALE)




def p3pl(theta, a, b, c):

    return c + (1 - c) * expit(1.702 * a * (theta - b))


def information_3pl(theta, a, b, c):

    p = p3pl(theta, a, b, c)
    q = 1 - p
    numerator = (1.702 ** 2) * (a ** 2) * ((p - c) ** 2)
    denominator = ((1 - c) ** 2) * (p * q + 1e-10)
    return numerator / denominator



def neg_log_likelihood(params, responses, theta_vec):

    a, b, c = params
    
    if a <= 0 or c < 0 or c > 0.35:
        return 1e10
    p = p3pl(theta_vec, a, b, c)
    p = np.clip(p, 1e-9, 1 - 1e-9)
    ll = np.sum(responses * np.log(p) + (1 - responses) * np.log(1 - p))
    return -ll



class IRTCalibration:


    RESPONSE_THRESHOLD = 30 

    def __init__(self):
        self.item_params = {}  

    def cold_start_from_seeds(self, items: list) -> dict:
        
        for item in items:
            item_id = item["item_id"]
            itype = item.get("item_type", "MCQ")
            self.item_params[item_id] = {
                "a": item.get("discrimination_seed", 1.2),
                "b": item.get("difficulty_seed", 0.0),
                "c": item.get("guessing_seed", 0.2) if itype == "MCQ" else 0.0,
                "source": "SME_SEED",
                "response_count": 0,
            }
        return self.item_params

    def update_empirical(self, item_id: str, responses: np.ndarray,
                         theta_estimates: np.ndarray) -> dict:
        
        if len(responses) < self.RESPONSE_THRESHOLD:
            self.item_params[item_id]["response_count"] = len(responses)
            self.item_params[item_id]["source"] = "SME_SEED"
            return self.item_params[item_id]

        seed = self.item_params.get(item_id, {"a": 1.0, "b": 0.0, "c": 0.2})
        x0 = [seed["a"], seed["b"], seed["c"]]

        bounds = [(0.5, 2.5), (-3.0, 3.0), (0.0, 0.35)]
        result = minimize(
            neg_log_likelihood,
            x0,
            args=(responses, theta_estimates),
            method="L-BFGS-B",
            bounds=bounds,
            options={"maxiter": 500, "ftol": 1e-9}
        )

        if result.success:
            a_hat, b_hat, c_hat = result.x
            self.item_params[item_id] = {
                "a": round(float(a_hat), 4),
                "b": round(float(b_hat), 4),
                "c": round(float(c_hat), 4),
                "source": "EMPIRICAL",
                "response_count": len(responses),
            }

        return self.item_params[item_id]

    def estimate_theta(self, item_ids: list, responses: list,
                       initial_theta: float = 0.0) -> tuple:
        
        def neg_ll_theta(theta_arr):
            theta = theta_arr[0]
            ll = 0.0
            for item_id, resp in zip(item_ids, responses):
                params = self.item_params.get(item_id)
                if params is None:
                    continue
                p = p3pl(theta, params["a"], params["b"], params["c"])
                p = np.clip(p, 1e-9, 1 - 1e-9)
                ll += resp * np.log(p) + (1 - resp) * np.log(1 - p)
            return -ll

        result = minimize(neg_ll_theta, [initial_theta], method="L-BFGS-B",
                          bounds=[(-4.0, 4.0)], options={"maxiter": 500})

        theta_hat = float(result.x[0])

        
        total_info = sum(
            information_3pl(theta_hat,
                            self.item_params[iid]["a"],
                            self.item_params[iid]["b"],
                            self.item_params[iid]["c"])
            for iid in item_ids if iid in self.item_params
        )
        sem = 1.0 / np.sqrt(max(total_info, 1e-6))
        return round(theta_hat, 4), round(float(sem), 4)

    def get_params(self, item_id: str) -> dict:
        return self.item_params.get(item_id)

    def export_params(self) -> dict:
        return {
            "model": "3PL",
            "scale": "logit",
            "parameters": self.item_params
        }




if __name__ == "__main__":
    import sys
    sys.path.insert(0, "..")


    try:
        with open("item_pool.json") as f:
            pool = json.load(f)
        items = pool["items"]
    except FileNotFoundError:
        print("Run item_pool.py first to generate item_pool.json")
        sys.exit(1)

    cal = IRTCalibration()
    cal.cold_start_from_seeds(items)
    print(f"Cold-started {len(cal.item_params)} items from SME seeds")


    rng = np.random.default_rng(42)
    sample_items = items[:10]
    item_ids = [i["item_id"] for i in sample_items]

    
    true_theta = 0.8
    params_list = [cal.get_params(iid) for iid in item_ids]
    probs = [p3pl(true_theta, p["a"], p["b"], p["c"]) for p in params_list]
    responses = [int(rng.random() < prob) for prob in probs]

    print(f"\nSimulated responses for theta={true_theta}: {responses}")
    theta_hat, sem = cal.estimate_theta(item_ids, responses)
    print(f"Estimated theta: {theta_hat}  SEM: {sem}")
    print(f"True vs estimated: |{true_theta} - {theta_hat}| = {abs(true_theta - theta_hat):.3f}")

    
    for item in sample_items[:3]:
        iid = item["item_id"]
        p = cal.get_params(iid)
        info = information_3pl(theta_hat, p["a"], p["b"], p["c"])
        print(f"  {iid} info@theta={theta_hat}: {info:.4f}")

    print("\nCalibration skeleton: OK")