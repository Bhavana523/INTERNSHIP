import json
import os
import sys
import time
import numpy as np

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

from Irt_calibration import IRTCalibration, p3pl, information_3pl
from Catengine import (
    CATEngine, InferenceEndpoint, AssessmentSession,
    theta_to_scaled_score, score_to_performance_band,
    SEM_STOP_THRESHOLD, MAX_ITEMS, MIN_ITEMS,
)
from proctoring.proctoring_engine import ProctoringEngine, ViolationType, Severity
from integration import (
    IntegratedPipeline, SignalFuser, FlagAggregator, IntegrityReporter,
    RecalibrationPipeline,
)
from recommendations import (
    RecommendationEngine, SkillVector, JOB_ROLES,
)



def load_item_pool() -> list:
    pool_path = os.path.join(_ROOT, "item_pool.json")
    with open(pool_path) as f:
        data = json.load(f)
    return data["items"]



def build_engines():
    
    items = load_item_pool()

    
    cal = IRTCalibration()
    cal.cold_start_from_seeds(items)

    
    cat_engine = CATEngine(items, cal)
    inference_ep = InferenceEndpoint(cat_engine)

    
    proc_engine = ProctoringEngine()

    
    rec_engine = RecommendationEngine(JOB_ROLES)

    
    fuser = SignalFuser()
    aggregator = FlagAggregator()
    reporter = IntegrityReporter()

    return {
        "items": items,
        "calibration": cal,
        "cat_engine": cat_engine,
        "inference_ep": inference_ep,
        "proc_engine": proc_engine,
        "rec_engine": rec_engine,
        "fuser": fuser,
        "aggregator": aggregator,
        "reporter": reporter,
    }



DEFAULT_STATE = {
    
    "page": "home",

    
    "student_id": None,
    "student_name": None,
    "assessment_id": None,
    "competency_id": "CSE001",

    
    "identity_verified": False,
    "identity_score": 0.0,
    "identity_reason": "",

    
    "cat_started": False,
    "cat_finished": False,
    "current_item": None,
    "item_count": 0,
    "cat_request": None,
    "theta_history": [],
    "sem_history": [],
    "item_history": [],    
    "current_theta": 0.0,
    "current_sem": 1.0,
    "final_score": None,

    
    "proctoring_started": False,
    "frame_count": 0,
    "violations": [],
    "risk_score": 0.0,
    "integrity_status": "PASS",
    "warning_count": 0,
    "auto_terminated": False,
    "proctoring_log": [],   

    
    "integrity_verdict": None,
    "flag_report": [],

    
    "recommendations": [],
    "skill_vector": None,

    
    "engines_loaded": False,
    "engines": None,
}


def init_state(st):
    
    for key, value in DEFAULT_STATE.items():
        if key not in st.session_state:
            st.session_state[key] = value


def ensure_engines(st):
    
    if not st.session_state.get("engines_loaded"):
        st.session_state["engines"] = build_engines()
        st.session_state["engines_loaded"] = True
    return st.session_state["engines"]



def start_cat_session(st_state, engines):
    
    student_id = st_state["student_id"]
    assessment_id = st_state["assessment_id"]
    competency_id = st_state["competency_id"]

    st_state["cat_request"] = {
        "student_id": student_id,
        "assessment_id": assessment_id,
        "current_competency_id": competency_id,
        "current_ability_estimate": 0.0,
    }
    st_state["cat_started"] = True
    st_state["item_count"] = 0
    st_state["theta_history"] = []
    st_state["sem_history"] = []
    st_state["item_history"] = []


def fetch_next_item(st_state, engines):
    
    ep = engines["inference_ep"]
    result = ep.next_item(st_state["cat_request"])

    if result["stop_test"]:
        st_state["cat_finished"] = True
        
        final = ep.get_final_score(
            st_state["student_id"],
            st_state["assessment_id"],
            st_state["competency_id"],
        )
        st_state["final_score"] = final
        return None

    
    item_id = result["next_item_id"]
    items = engines["items"]
    item_data = next((i for i in items if i["item_id"] == item_id), None)

    st_state["current_item"] = {
        "item_id": item_id,
        "item_data": item_data,
        "difficulty_band": result["difficulty_band"],
        "reason": result["reason"],
        "sem": result["sem"],
        "theta": result["theta"],
    }
    return st_state["current_item"]


def submit_response(st_state, engines, response: int):
    
    ep = engines["inference_ep"]
    item_id = st_state["current_item"]["item_id"]

    state_result = ep.submit_response(
        st_state["student_id"],
        st_state["assessment_id"],
        st_state["competency_id"],
        item_id,
        response,
    )

    
    st_state["current_theta"] = state_result["theta"]
    st_state["current_sem"] = state_result["sem"]
    st_state["item_count"] += 1
    st_state["theta_history"].append(state_result["theta"])
    st_state["sem_history"].append(state_result["sem"])

    
    item_data = st_state["current_item"].get("item_data", {})
    st_state["item_history"].append({
        "item_id": item_id,
        "question": item_data.get("question_text", "N/A") if item_data else "N/A",
        "difficulty": item_data.get("difficulty_band", "?") if item_data else "?",
        "response": response,
        "theta": state_result["theta"],
        "sem": state_result["sem"],
    })

    
    st_state["cat_request"]["current_ability_estimate"] = state_result["theta"]

    if state_result["stopped"]:
        st_state["cat_finished"] = True
        final = ep.get_final_score(
            st_state["student_id"],
            st_state["assessment_id"],
            st_state["competency_id"],
        )
        st_state["final_score"] = final

    return state_result



def start_proctoring(st_state, engines):
    
    proc = engines["proc_engine"]
    student_id = st_state["student_id"]
    assessment_id = st_state["assessment_id"]

    photo_bytes = f"PHOTO_{student_id}_{assessment_id}".encode()
    result = proc.start_session(
        student_id=student_id,
        assessment_id=assessment_id,
        registered_photo=photo_bytes,
        live_photo=photo_bytes,
    )
    st_state["identity_verified"] = result["identity_verified"]
    st_state["identity_score"] = result["match_score"]
    st_state["identity_reason"] = result["reason"]
    st_state["proctoring_started"] = True
    return result


def process_proctoring_frame(
    st_state,
    engines,
    frame_bytes=None,
    scenario="clean"
):
    proc = engines["proc_engine"]

    student_id = st_state["student_id"]
    assessment_id = st_state["assessment_id"]

    result = proc.process_frame(
        student_id=student_id,
        assessment_id=assessment_id,
        frame_bytes=frame_bytes,
        inject_scenario=scenario,
    )
    st_state["frame_count"] += 1
    st_state["risk_score"] = result["risk_score"]
    st_state["integrity_status"] = result["integrity_status"]
    st_state["warning_count"] = result["warning_count"]
    st_state["auto_terminated"] = result["auto_terminated"]

    
    signal = result.get("frame_signal", {})
    if signal.get("violations_detected"):
        for v in signal["violations_detected"]:
            st_state["violations"].append({
                "frame": st_state["frame_count"],
                "type": v,
                "timestamp": time.strftime("%H:%M:%S"),
                "risk": result["risk_score"],
            })

    st_state["proctoring_log"].append({
        "frame": st_state["frame_count"],
        "risk": result["risk_score"],
        "status": result["integrity_status"],
    })

    return result


def ingest_behavioral_event(st_state, engines, event_type: str):
    
    proc = engines["proc_engine"]
    result = proc.ingest_behavioral_event(
        st_state["student_id"],
        st_state["assessment_id"],
        event_type,
    )
    st_state["risk_score"] = result.get("risk_score", st_state["risk_score"])
    st_state["integrity_status"] = result.get("integrity_status", st_state["integrity_status"])
    st_state["violations"].append({
        "frame": "behavioral",
        "type": event_type.upper(),
        "timestamp": time.strftime("%H:%M:%S"),
        "risk": result.get("risk_score", 0),
    })
    return result


def finalize_proctoring(st_state, engines):
    
    proc = engines["proc_engine"]
    fuser = engines["fuser"]
    aggregator = engines["aggregator"]
    reporter = engines["reporter"]

    proc_report = proc.get_integrity_report(
        st_state["student_id"],
        st_state["assessment_id"],
    )

    
    from integration import SignalBundle
    bundle = SignalBundle(
        student_id=st_state["student_id"],
        assessment_id=st_state["assessment_id"],
        vision_risk=proc_report.get("risk_score", 0.0),
        audio_risk=0.05,
        behavioral_risk=min(1.0, len([v for v in st_state["violations"]
                                       if v["type"] in ("TAB_SWITCH", "BROWSER_MINIMIZE")]) * 0.15),
    )
    fused_risk = fuser.fuse(bundle)

    behavioral_events = [
        {"type": v["type"].lower(), "timestamp": v["timestamp"]}
        for v in st_state["violations"]
        if v["frame"] == "behavioral"
    ]
    flags = aggregator.aggregate(proc_report, behavioral_events)
    verdict = reporter.generate_verdict(
        st_state["student_id"],
        st_state["assessment_id"],
        fused_risk,
        flags,
        proc_report,
    )

    st_state["integrity_verdict"] = verdict.to_dict()
    st_state["flag_report"] = flags
    return verdict.to_dict()



def generate_recommendations(st_state, engines):
    
    rec_engine = engines["rec_engine"]
    final_score = st_state.get("final_score", {})

    sv = SkillVector(student_id=st_state["student_id"])
    if final_score:
        sv.add_score(
            competency_id=st_state["competency_id"],
            scaled_score=final_score.get("scaled_score", 500),
            performance_band=final_score.get("performance_band", "Average"),
            theta=final_score.get("ability_estimate", 0.0),
            sem=final_score.get("sem", 0.3),
        )

    recs = rec_engine.recommend(sv, top_n=5)
    st_state["recommendations"] = [r.to_dict() for r in recs]
    st_state["skill_vector"] = sv
    return st_state["recommendations"]