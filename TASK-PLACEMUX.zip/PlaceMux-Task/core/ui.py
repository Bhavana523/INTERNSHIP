import streamlit as st

GLOBAL_CSS = """
<style>
/* ── Base ── */
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');

html, body, [class*="css"] {
    font-family: 'Inter', sans-serif;
}

/* ── Hide default Streamlit chrome ── */
#MainMenu, footer, header { visibility: hidden; }
.stDeployButton { display: none; }
section[data-testid="stSidebar"] { background: #111128 !important; }

/* ── Metric cards ── */
div[data-testid="metric-container"] {
    background: #1E1E35;
    border: 1px solid #2D2D55;
    border-radius: 12px;
    padding: 1rem 1.25rem;
}
div[data-testid="metric-container"] label {
    color: #9090C0 !important;
    font-size: 12px !important;
    letter-spacing: 0.05em;
    text-transform: uppercase;
}
div[data-testid="metric-container"] div[data-testid="stMetricValue"] {
    font-size: 1.8rem !important;
    font-weight: 600;
    color: #E8E8F8 !important;
}

/* ── Cards ── */
.pm-card {
    background: #1A1A30;
    border: 1px solid #2D2D55;
    border-radius: 16px;
    padding: 1.5rem;
    margin-bottom: 1rem;
}
.pm-card-accent {
    background: linear-gradient(135deg, #1E1040 0%, #1A1A30 100%);
    border: 1px solid #5B3EC4;
    border-radius: 16px;
    padding: 1.5rem;
    margin-bottom: 1rem;
}

/* ── Badges ── */
.badge-pass   { background:#0D3D1E; color:#34D399; border:1px solid #34D399; border-radius:6px; padding:3px 10px; font-size:12px; font-weight:600; }
.badge-warn   { background:#3D2E00; color:#FCD34D; border:1px solid #FCD34D; border-radius:6px; padding:3px 10px; font-size:12px; font-weight:600; }
.badge-fail   { background:#3D0D0D; color:#F87171; border:1px solid #F87171; border-radius:6px; padding:3px 10px; font-size:12px; font-weight:600; }
.badge-info   { background:#0D1F3D; color:#60A5FA; border:1px solid #60A5FA; border-radius:6px; padding:3px 10px; font-size:12px; font-weight:600; }

/* ── Progress bar override ── */
.stProgress > div > div > div > div {
    background: linear-gradient(90deg, #6C3FC5, #A855F7) !important;
}

/* ── Sidebar nav buttons ── */
.nav-btn {
    width: 100%;
    text-align: left;
    background: transparent;
    border: none;
    color: #9090C0;
    padding: 10px 16px;
    border-radius: 8px;
    cursor: pointer;
    font-size: 14px;
    transition: all 0.2s;
}
.nav-btn:hover { background: #2D2D55; color: #E8E8F8; }
.nav-btn.active { background: #2D1F5E; color: #A78BFA; border-left: 3px solid #7C3AED; }

/* ── Table styling ── */
.stDataFrame { border-radius: 12px; overflow: hidden; }

/* ── Violation row colors ── */
.viol-high { color: #F87171; font-weight: 600; }
.viol-medium { color: #FCD34D; font-weight: 600; }
.viol-low { color: #34D399; }

/* ── Section title ── */
.section-title {
    font-size: 11px;
    font-weight: 600;
    letter-spacing: 0.1em;
    text-transform: uppercase;
    color: #6060A0;
    margin: 1.5rem 0 0.5rem;
}
</style>
"""


def inject_css():
    st.markdown(GLOBAL_CSS, unsafe_allow_html=True)


# ── Page header ───────────────────────────────────────────────────────────────

def page_header(title: str, subtitle: str = "", icon: str = ""):
    icon_html = f"<span style='font-size:28px; margin-right:12px'>{icon}</span>" if icon else ""
    st.markdown(f"""
    <div style='padding: 1.5rem 0 1rem; border-bottom: 1px solid #2D2D55; margin-bottom: 1.5rem;'>
      <div style='display:flex; align-items:center;'>
        {icon_html}
        <div>
          <h1 style='margin:0; font-size:24px; font-weight:600; color:#E8E8F8;'>{title}</h1>
          {"<p style='margin:4px 0 0; color:#7070A8; font-size:14px;'>" + subtitle + "</p>" if subtitle else ""}
        </div>
      </div>
    </div>
    """, unsafe_allow_html=True)


# ── Risk meter ────────────────────────────────────────────────────────────────

def risk_meter(risk_score: float, label: str = "Risk Score"):
    pct = int(risk_score * 100)
    if risk_score <= 0.30:
        color = "#34D399"
        status = "PASS"
        badge_cls = "badge-pass"
    elif risk_score <= 0.70:
        color = "#FCD34D"
        status = "WARNING"
        badge_cls = "badge-warn"
    else:
        color = "#F87171"
        status = "FAIL"
        badge_cls = "badge-fail"

    st.markdown(f"""
    <div class='pm-card' style='text-align:center;'>
      <p style='color:#9090C0; font-size:12px; text-transform:uppercase; letter-spacing:0.08em; margin:0 0 8px;'>{label}</p>
      <div style='font-size:42px; font-weight:700; color:{color}; margin:4px 0;'>{pct}%</div>
      <div style='background:#0F0F1A; border-radius:8px; height:10px; margin:12px 0 10px; overflow:hidden;'>
        <div style='height:100%; width:{pct}%; background:{color}; border-radius:8px; transition:width 0.5s;'></div>
      </div>
      <span class='{badge_cls}'>{status}</span>
    </div>
    """, unsafe_allow_html=True)



def integrity_badge(status: str):
    mapping = {
        "PASS": ("badge-pass", "✓ PASS"),
        "WARNING": ("badge-warn", "⚠ WARNING"),
        "FAIL": ("badge-fail", "✗ FAIL"),
        "REVIEW": ("badge-info", "↗ REVIEW"),
    }
    cls, label = mapping.get(status, ("badge-info", status))
    st.markdown(f"<span class='{cls}'>{label}</span>", unsafe_allow_html=True)



def performance_pill(band: str):
    colors = {
        "Excellent": ("#7C3AED", "#EDE9FE"),
        "Good": ("#0891B2", "#E0F2FE"),
        "Average": ("#D97706", "#FEF3C7"),
        "Beginner": ("#6B7280", "#F3F4F6"),
    }
    bg, fg = colors.get(band, ("#6B7280", "#F3F4F6"))
    st.markdown(f"""
    <span style='background:{bg}; color:{fg}; border-radius:20px; padding:6px 18px;
                 font-weight:600; font-size:14px;'>{band}</span>
    """, unsafe_allow_html=True)



NAV_PAGES = [
    ("home",          "🏠", "Home"),
    ("login",         "👤", "Student Login"),
    ("assessment",    "📝", "CAT Assessment"),
    ("proctoring",    "🎥", "Proctoring"),
    ("results",       "📊", "Results"),
    ("recommendations","💼", "Recommendations"),
    ("admin",         "🛡️", "Admin Dashboard"),
]

def sidebar_nav():
    with st.sidebar:
        st.markdown("""
        <div style='padding: 1rem 0.5rem 0.5rem;'>
          <div style='font-size:20px; font-weight:700; color:#A78BFA; letter-spacing:0.02em;'>
            PlaceMux
          </div>
          <div style='font-size:11px; color:#6060A0; margin-top:2px;'>AI Assessment Platform</div>
        </div>
        <hr style='border:none; border-top:1px solid #2D2D55; margin:0.75rem 0;'/>
        """, unsafe_allow_html=True)

        current = st.session_state.get("page", "home")
        for page_id, icon, label in NAV_PAGES:
            is_active = current == page_id
            if st.button(
                f"{icon}  {label}",
                key=f"nav_{page_id}",
                use_container_width=True,
                type="secondary" if not is_active else "primary",
            ):
                st.session_state["page"] = page_id
                st.rerun()

        st.markdown("<hr style='border:none; border-top:1px solid #2D2D55; margin:1rem 0;'/>", unsafe_allow_html=True)

        if st.session_state.get("student_id"):
            st.markdown(f"""
            <div style='padding:0.75rem; background:#1A1A30; border-radius:10px; border:1px solid #2D2D55;'>
              <div style='font-size:11px; color:#6060A0; text-transform:uppercase; letter-spacing:0.05em;'>Active Student</div>
              <div style='font-size:14px; color:#E8E8F8; font-weight:500; margin-top:2px;'>{st.session_state.get("student_name", "")}</div>
              <div style='font-size:11px; color:#7070A0; margin-top:1px;'>{st.session_state.get("student_id", "")}</div>
            </div>
            """, unsafe_allow_html=True)

            st.markdown("<div class='section-title'>Session Status</div>", unsafe_allow_html=True)
            col1, col2 = st.columns(2)
            with col1:
                id_ok = st.session_state.get("identity_verified", False)
                st.markdown(f"<div style='font-size:12px; color:{'#34D399' if id_ok else '#F87171'};'>{'✓' if id_ok else '✗'} Identity</div>", unsafe_allow_html=True)
            with col2:
                cat_ok = st.session_state.get("cat_finished", False)
                st.markdown(f"<div style='font-size:12px; color:{'#34D399' if cat_ok else '#9090C0'};'>{'✓' if cat_ok else '○'} Assessment</div>", unsafe_allow_html=True)

            risk = st.session_state.get("risk_score", 0.0)
            risk_color = "#34D399" if risk <= 0.30 else "#FCD34D" if risk <= 0.70 else "#F87171"
            st.markdown(f"<div style='font-size:12px; color:{risk_color}; margin-top:4px;'>⚠ Risk: {int(risk*100)}%</div>", unsafe_allow_html=True)



def theta_chart(theta_history: list):
    if not theta_history:
        st.info("No ability estimates yet.")
        return
    import pandas as pd
    df = pd.DataFrame({
        "Item": list(range(1, len(theta_history) + 1)),
        "Theta (Ability Estimate)": theta_history,
    })
    st.line_chart(df.set_index("Item"), color="#A78BFA", height=200)



def violation_table(violations: list):
    if not violations:
        st.markdown("<div style='color:#34D399; font-size:13px;'>✓ No violations detected</div>", unsafe_allow_html=True)
        return
    import pandas as pd
    df = pd.DataFrame(violations)
    df = df[["timestamp", "type", "risk", "frame"]].rename(columns={
        "timestamp": "Time", "type": "Violation", "risk": "Risk", "frame": "Frame"
    })
    st.dataframe(df, use_container_width=True, hide_index=True)