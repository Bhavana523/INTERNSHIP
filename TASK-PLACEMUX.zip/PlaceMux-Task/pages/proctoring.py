
import av
import streamlit as st
from streamlit_webrtc import webrtc_streamer, VideoProcessorBase
import time
from core.ui import page_header, inject_css, risk_meter, integrity_badge, violation_table
from core.engine import (
    ensure_engines, process_proctoring_frame, ingest_behavioral_event, finalize_proctoring,
)


SCENARIOS = {
    "Clean Frame": "clean",
    "Multiple Faces Detected": "multiple_faces",
    "No Face Detected": "no_face",
    "Suspicious Head Movement": "head_movement",
}

BEHAVIORAL_EVENTS = {
    "Tab Switch": "tab_switch",
    "Browser Minimize": "browser_minimize",
    "External Device": "external_device",
}


class ProctoringVideoProcessor(VideoProcessorBase):

    def __init__(self):
        self.last_frame = None

    def recv(self, frame):

        img = frame.to_ndarray(format="bgr24")

        self.last_frame = img

        return av.VideoFrame.from_ndarray(
            img,
            format="bgr24"
        )


def render():
    inject_css()

    if not st.session_state.get("student_id"):
        st.warning("Please log in first.")
        if st.button("Go to Login"):
            st.session_state["page"] = "login"
            st.rerun()
        return

    engines = ensure_engines(st)
    page_header(
        "Proctoring Dashboard",
        f"Session monitoring for {st.session_state.get('student_name')} · {st.session_state.get('assessment_id')}",
        "🎥"
    )

    c1, c2, c3, c4 = st.columns(4)

    with c1:
        id_ok = st.session_state.get("identity_verified", False)
        id_score = st.session_state.get("identity_score", 0.0)
        color = "#34D399" if id_ok else "#F87171"
        icon = "✓" if id_ok else "✗"
        st.markdown(f"""
        <div class='pm-card' style='text-align:center;'>
          <div style='font-size:11px; color:#6060A0; text-transform:uppercase; letter-spacing:0.06em; margin-bottom:6px;'>Identity</div>
          <div style='font-size:28px; font-weight:700; color:{color};'>{icon}</div>
          <div style='font-size:12px; color:#7070A8; margin-top:4px;'>Match: {id_score:.3f}</div>
          <div style='font-size:11px; color:{color}; margin-top:2px;'>{"Verified" if id_ok else "Unverified"}</div>
        </div>
        """, unsafe_allow_html=True)

    with c2:
        frames = st.session_state.get("frame_count", 0)
        st.markdown(f"""
        <div class='pm-card' style='text-align:center;'>
          <div style='font-size:11px; color:#6060A0; text-transform:uppercase; letter-spacing:0.06em; margin-bottom:6px;'>Frames Analyzed</div>
          <div style='font-size:28px; font-weight:700; color:#A78BFA;'>{frames}</div>
          <div style='font-size:11px; color:#6060A0; margin-top:2px;'>Live feed active</div>
        </div>
        """, unsafe_allow_html=True)

    with c3:
        warnings = st.session_state.get("warning_count", 0)
        warn_color = "#34D399" if warnings == 0 else "#FCD34D" if warnings < 3 else "#F87171"
        st.markdown(f"""
        <div class='pm-card' style='text-align:center;'>
          <div style='font-size:11px; color:#6060A0; text-transform:uppercase; letter-spacing:0.06em; margin-bottom:6px;'>Warnings</div>
          <div style='font-size:28px; font-weight:700; color:{warn_color};'>{warnings}/3</div>
          <div style='font-size:11px; color:#6060A0; margin-top:2px;'>Auto-terminate at 3</div>
        </div>
        """, unsafe_allow_html=True)

    with c4:
        violations = st.session_state.get("violations", [])
        viol_color = "#34D399" if not violations else "#FCD34D" if len(violations) < 3 else "#F87171"
        st.markdown(f"""
        <div class='pm-card' style='text-align:center;'>
          <div style='font-size:11px; color:#6060A0; text-transform:uppercase; letter-spacing:0.06em; margin-bottom:6px;'>Violations</div>
          <div style='font-size:28px; font-weight:700; color:{viol_color};'>{len(violations)}</div>
          <div style='font-size:11px; color:#6060A0; margin-top:2px;'>Logged events</div>
        </div>
        """, unsafe_allow_html=True)

    st.markdown("<br/>", unsafe_allow_html=True)

    left, right = st.columns([2, 1])

    with left:
        st.subheader("📹 Live Proctoring Camera")
        img_file = st.camera_input("Take a verification snapshot")

        import cv2

        if img_file is not None:
            frame_bytes = img_file.getvalue()

            result = process_proctoring_frame(
                st.session_state,
                engines,
                frame_bytes=frame_bytes,
                scenario="clean"
            )

            st.success("Frame analyzed successfully")
            st.write(result)

        violation_table(st.session_state.get("violations", []))
        st.markdown("</div>", unsafe_allow_html=True)

        frame_log = st.session_state.get("proctoring_log", [])
        if len(frame_log) > 1:
            st.markdown("<div style='font-size:12px; color:#A78BFA; font-weight:600; margin-bottom:6px;'>Risk Score Over Time</div>", unsafe_allow_html=True)
            import pandas as pd
            df = pd.DataFrame([{"Frame": f["frame"], "Risk": f["risk"]} for f in frame_log])
            st.line_chart(df.set_index("Frame"), color="#F87171", height=150)

    with right:
        risk_meter(st.session_state.get("risk_score", 0.0))

        st.markdown("""
        <div class='pm-card' style='text-align:center; margin-top:12px;'>
          <div style='font-size:11px; color:#6060A0; text-transform:uppercase; letter-spacing:0.06em; margin-bottom:8px;'>
            Integrity Status
          </div>
        """, unsafe_allow_html=True)
        integrity_badge(st.session_state.get("integrity_status", "PASS"))
        st.markdown("</div>", unsafe_allow_html=True)

        st.markdown("""
        <div class='pm-card' style='margin-top:12px;'>
          <div style='font-size:12px; color:#A78BFA; font-weight:600; margin-bottom:10px;'>
            Signal Fusion Weights
          </div>
        """, unsafe_allow_html=True)
        weights = [("Vision (Camera)", 55, "#7C3AED"), ("Behavioral", 30, "#0891B2"), ("Audio (stub)", 15, "#D97706")]
        for label, pct, color in weights:
            st.markdown(f"""
            <div style='margin-bottom:8px;'>
              <div style='display:flex; justify-content:space-between; font-size:11px; color:#7070A8; margin-bottom:3px;'>
                <span>{label}</span><span>{pct}%</span>
              </div>
              <div style='background:#0F0F1A; border-radius:4px; height:6px;'>
                <div style='height:100%; width:{pct}%; background:{color}; border-radius:4px;'></div>
              </div>
            </div>
            """, unsafe_allow_html=True)
        st.markdown("</div>", unsafe_allow_html=True)

        violations = st.session_state.get("violations", [])
        if violations:
            from collections import Counter
            counts = Counter(v["type"] for v in violations)
            st.markdown("""
            <div class='pm-card' style='margin-top:12px;'>
              <div style='font-size:12px; color:#A78BFA; font-weight:600; margin-bottom:10px;'>Violation Breakdown</div>
            """, unsafe_allow_html=True)
            for vtype, cnt in counts.most_common():
                st.markdown(f"""
                <div style='display:flex; justify-content:space-between; font-size:11px;
                            padding:4px 0; border-bottom:1px solid #1A1A30;'>
                  <span style='color:#E8E8F8;'>{vtype.replace("_", " ").title()}</span>
                  <span style='color:#F87171; font-weight:600;'>×{cnt}</span>
                </div>
                """, unsafe_allow_html=True)
            st.markdown("</div>", unsafe_allow_html=True)

        if st.session_state.get("auto_terminated"):
            st.error("🚫 Session AUTO-TERMINATED — 3 warnings reached. Exam submitted.")

        st.markdown("<br/>", unsafe_allow_html=True)
        if st.button("📊  Generate Integrity Report", use_container_width=True, type="primary"):
            with st.spinner("Generating integrity verdict..."):
                verdict = finalize_proctoring(st.session_state, engines)
            st.success("Integrity verdict generated!")
            st.rerun()

        if st.session_state.get("integrity_verdict"):
            verdict = st.session_state["integrity_verdict"]
            st.markdown(f"""
            <div class='pm-card' style='margin-top:10px;'>
              <div style='font-size:12px; color:#A78BFA; font-weight:600; margin-bottom:8px;'>Verdict</div>
              <div style='font-size:11px; color:#7070A8; line-height:1.6;'>
                <b style='color:#E8E8F8;'>Status:</b> {verdict.get("integrity_status")}<br/>
                <b style='color:#E8E8F8;'>Fused Risk:</b> {verdict.get("risk_score")}<br/>
                <b style='color:#E8E8F8;'>Action:</b> {verdict.get("action")}<br/>
                <b style='color:#E8E8F8;'>Review:</b> {"Yes" if verdict.get("route_to_review") else "No"}
              </div>
            </div>
            """, unsafe_allow_html=True)
