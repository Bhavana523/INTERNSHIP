
import streamlit as st
import time
import uuid
from core.ui import page_header, inject_css, integrity_badge
from core.engine import ensure_engines, start_proctoring


COMPETENCY_OPTIONS = {
    "Python Programming (CSE001)": "CSE001",
    "DSA — Arrays & Strings (CSE006)": "CSE006",
    "SQL & Database (CSE012)": "CSE012",
    "Web Development Backend (CSE026)": "CSE026",
    "AI/ML Supervised Learning (CSE035)": "CSE035",
    "Cloud & DevOps — AWS (CSE030)": "CSE030",
    "Embedded Systems (ECE005)": "ECE005",
    "VLSI Design (ECE014)": "ECE014",
}

BRANCH_OPTIONS = ["CSE", "ECE", "EEE", "MECH", "CIVIL"]


def render():
    inject_css()
    page_header("Student Authentication", "Log in and verify your identity to begin", "👤")
    engines = ensure_engines(st)

    if st.session_state.get("student_id") and st.session_state.get("identity_verified"):
        st.markdown(f"""
        <div class='pm-card-accent'>
          <div style='font-size:14px; color:#34D399; font-weight:600; margin-bottom:8px;'>
            ✓ Already authenticated as {st.session_state.get("student_name")}
          </div>
          <div style='font-size:12px; color:#7070A8;'>
            Student ID: {st.session_state.get("student_id")} &nbsp;|&nbsp;
            Assessment: {st.session_state.get("assessment_id")}
          </div>
        </div>
        """, unsafe_allow_html=True)

        col1, col2 = st.columns(2)
        with col1:
            if st.button("▶  Continue to Assessment", type="primary", use_container_width=True):
                st.session_state["page"] = "assessment"
                st.rerun()
        with col2:
            if st.button("↺  Start New Session", use_container_width=True):
                for key in ["student_id", "student_name", "assessment_id",
                            "identity_verified", "cat_started", "cat_finished",
                            "engines_loaded"]:
                    if key in st.session_state:
                        del st.session_state[key]
                st.rerun()
        return

    col_form, col_info = st.columns([3, 2])

    with col_form:
        st.markdown("<div class='pm-card'>", unsafe_allow_html=True)
        st.markdown("<div style='font-size:14px; font-weight:600; color:#A78BFA; margin-bottom:16px;'>Student Details</div>", unsafe_allow_html=True)

        name = st.text_input("Full Name", placeholder="e.g. Rahul Sharma", key="input_name")
        student_id_raw = st.text_input("Roll Number / Student ID", placeholder="e.g. 2024CSE0101", key="input_id")
        branch = st.selectbox("Branch", BRANCH_OPTIONS, key="input_branch")
        college = st.text_input("College Name", placeholder="e.g. NIT Trichy", key="input_college")

        st.markdown("<div style='margin-top:12px;'></div>", unsafe_allow_html=True)
        st.markdown("<div style='font-size:13px; color:#7070A8; margin-bottom:8px;'>Select Assessment Competency</div>", unsafe_allow_html=True)
        competency_label = st.selectbox(
            "Competency",
            list(COMPETENCY_OPTIONS.keys()),
            key="input_competency",
            label_visibility="collapsed",
        )
        competency_id = COMPETENCY_OPTIONS[competency_label]

        st.markdown("</div>", unsafe_allow_html=True)

        st.markdown("<br/>", unsafe_allow_html=True)

        st.markdown("""
        <div class='pm-card'>
          <div style='font-size:14px; font-weight:600; color:#A78BFA; margin-bottom:8px;'>
            🎥 Identity Verification
          </div>
          <div style='font-size:12px; color:#7070A8; margin-bottom:12px; line-height:1.6;'>
            In production, this step uses your webcam to match your face against
            your registered ID photo using FaceNet embeddings. For this demonstration,
            the system simulates the face-match using the Day 4 proctoring engine.
          </div>
        </div>
        """, unsafe_allow_html=True)

        proceed_clicked = st.button("🔐  Verify Identity & Proceed", type="primary", use_container_width=True)

    with col_info:
        st.markdown("""
        <div class='pm-card' style='height:100%;'>
          <div style='font-size:13px; color:#A78BFA; font-weight:600; margin-bottom:12px;'>
            What happens next
          </div>
        """, unsafe_allow_html=True)

        steps = [
            ("1", "Identity Verification", "Your face is matched against the registered photo using the Day 4 ProctoringEngine"),
            ("2", "Session Initialization", "A unique assessment session is created with the CAT engine"),
            ("3", "IRT Cold-Start", "SME-seeded item parameters are loaded for your selected competency"),
            ("4", "Proctoring Begins", "Background monitoring starts — presence detection runs per-frame"),
        ]
        for num, title, desc in steps:
            st.markdown(f"""
            <div style='display:flex; gap:12px; margin-bottom:14px;'>
              <div style='width:24px; height:24px; background:#2D1F5E; border-radius:50%;
                          display:flex; align-items:center; justify-content:center;
                          font-size:11px; font-weight:700; color:#A78BFA; flex-shrink:0;'>{num}</div>
              <div>
                <div style='font-size:13px; font-weight:500; color:#E8E8F8;'>{title}</div>
                <div style='font-size:11px; color:#6060A0; margin-top:2px; line-height:1.4;'>{desc}</div>
              </div>
            </div>
            """, unsafe_allow_html=True)

        st.markdown("</div>", unsafe_allow_html=True)

        st.markdown("""
        <div class='pm-card' style='margin-top:12px;'>
          <div style='font-size:13px; color:#FCD34D; font-weight:600; margin-bottom:8px;'>
            📱 Dual-Camera Proctoring
          </div>
          <div style='font-size:12px; color:#7070A8; line-height:1.6;'>
            This platform implements dual-camera proctoring (laptop webcam + mobile side camera)
            as documented in the project spec. Both camera signals are fused into a single
            integrity verdict using the Day 5 SignalFuser.
          </div>
        </div>
        """, unsafe_allow_html=True)

    if proceed_clicked:
        if not name.strip() or not student_id_raw.strip():
            st.error("Please fill in your name and student ID.")
            return

        student_id = student_id_raw.strip().upper()
        assessment_id = f"ASM_{student_id}_{int(time.time()) % 10000:04d}"

        st.session_state["student_id"] = student_id
        st.session_state["student_name"] = name.strip()
        st.session_state["assessment_id"] = assessment_id
        st.session_state["competency_id"] = competency_id
        st.session_state["college"] = college
        st.session_state["branch"] = branch

        with st.spinner("Running identity verification..."):
            time.sleep(0.5)  
            result = start_proctoring(st.session_state, engines)

        if result["identity_verified"]:
            st.success(f"✓ Identity verified! Match score: {result['match_score']:.3f}")
        else:
            
            st.warning(f"""
            ⚠ Identity match score: {result['match_score']:.3f} (stub mode — real webcam not available in demo).
            Proceeding with session for demonstration purposes.
            """)
            
            st.session_state["identity_verified"] = True
            st.session_state["identity_score"] = result["match_score"]
            st.session_state["identity_reason"] = "Demo mode — stub face matching"

        st.markdown(f"""
        <div class='pm-card' style='margin-top:1rem;'>
          <div style='font-size:13px; font-weight:600; color:#34D399; margin-bottom:8px;'>
            ✓ Session Created
          </div>
          <div style='font-size:12px; color:#7070A8; line-height:1.8;'>
            <b style='color:#E8E8F8;'>Student:</b> {name}<br/>
            <b style='color:#E8E8F8;'>ID:</b> {student_id}<br/>
            <b style='color:#E8E8F8;'>Assessment:</b> {assessment_id}<br/>
            <b style='color:#E8E8F8;'>Competency:</b> {competency_label}<br/>
            <b style='color:#E8E8F8;'>Branch:</b> {branch}
          </div>
        </div>
        """, unsafe_allow_html=True)

        time.sleep(0.5)
        if st.button("▶  Begin Assessment", type="primary", use_container_width=True):
            st.session_state["page"] = "assessment"
            st.rerun()