import streamlit as st
from core.ui import page_header, inject_css


def render():
    inject_css()

    st.markdown("""
    <div style='text-align:center; padding: 3rem 1rem 2rem;'>
      <div style='font-size:56px; margin-bottom:12px;'>🎓</div>
      <h1 style='font-size:40px; font-weight:700; color:#E8E8F8; margin:0;'>PlaceMux</h1>
      <p style='font-size:18px; color:#7070A8; margin:8px 0 0;'>
        AI-Powered Adaptive Assessment Platform
      </p>
      <p style='font-size:13px; color:#5050A0; margin-top:6px;'>
        IRT-Calibrated · Computer Adaptive Testing · AI Proctoring · Smart Recommendations
      </p>
    </div>
    """, unsafe_allow_html=True)

    cols = st.columns(4)
    features = [
        ("🧠", "Adaptive Testing", "3PL IRT-calibrated CAT engine adjusts difficulty per response"),
        ("👁️", "AI Proctoring", "Identity verification + dual-signal presence detection"),
        ("📊", "Psychometrics", "Real-time theta estimation with SEM precision control"),
        ("💼", "Career Match", "Skill-vector to ranked job role recommendations"),
    ]
    for col, (icon, title, desc) in zip(cols, features):
        with col:
            st.markdown(f"""
            <div class='pm-card' style='text-align:center; height:160px;'>
              <div style='font-size:30px; margin-bottom:8px;'>{icon}</div>
              <div style='font-size:14px; font-weight:600; color:#E8E8F8; margin-bottom:6px;'>{title}</div>
              <div style='font-size:12px; color:#7070A8; line-height:1.5;'>{desc}</div>
            </div>
            """, unsafe_allow_html=True)

    st.markdown("<br/>", unsafe_allow_html=True)

    st.markdown("""
    <div class='pm-card-accent'>
      <div style='font-size:13px; color:#A78BFA; font-weight:600; text-transform:uppercase;
                  letter-spacing:0.08em; margin-bottom:12px;'>Technology Stack</div>
      <div style='display:grid; grid-template-columns: repeat(3, 1fr); gap:12px;'>
    """, unsafe_allow_html=True)

    stack_items = [
        ("Day 2", "IRT Calibration", "3PL model · Fisher Information · MLE"),
        ("Day 3", "CAT Engine", "Max-info selection · Exposure control"),
        ("Day 4", "Proctoring Core", "Identity verify · Presence detect · Behavioral"),
        ("Day 5", "E2E Integration", "Signal fusion · Integrity verdict · Recalibration"),
        ("Day 6", "Recommendations", "Skill vector → ranked roles · Why-match"),
        ("Day 7", "Validation", "Reliability · Fairness · Dry run · GO/NO-GO"),
    ]

    cols2 = st.columns(3)
    for i, (day, title, detail) in enumerate(stack_items):
        with cols2[i % 3]:
            st.markdown(f"""
            <div style='background:#111128; border:1px solid #2D2D55; border-radius:10px;
                        padding:12px; margin-bottom:10px;'>
              <div style='font-size:10px; color:#6C3FC5; text-transform:uppercase;
                          letter-spacing:0.08em; margin-bottom:4px;'>{day}</div>
              <div style='font-size:13px; font-weight:600; color:#E8E8F8;'>{title}</div>
              <div style='font-size:11px; color:#5050A0; margin-top:3px;'>{detail}</div>
            </div>
            """, unsafe_allow_html=True)

    st.markdown("<br/>", unsafe_allow_html=True)

    st.markdown("<div style='font-size:14px; font-weight:600; color:#A78BFA; margin-bottom:12px;'>7-Day Sprint Overview</div>", unsafe_allow_html=True)

    sprint_data = {
        "Day": ["Day 1", "Day 2", "Day 3", "Day 4", "Day 5", "Day 6", "Day 7"],
        "Theme": ["Setup & Contracts", "Auth & Pipelines", "Profiles & Data Flows",
                  "Assessment + Proctoring Core", "End-to-End Integration",
                  "Prep, Scores & Recommendations", "Stabilize & Dry Run"],
        "Status": ["✅ Done", "✅ Done", "✅ Done", "✅ Done", "✅ Done", "✅ Done", "✅ GO"],
        "AI/ML Output": [
            "Skills ontology · Item schema · API contracts",
            "Item pool seeded · 3PL IRT model · Calibration scaffold",
            "CAT engine · Theta estimation · Stub endpoint",
            "Proctoring core · Identity verify · Presence detect",
            "Signal fusion · Integrity verdict · Recalibration pipeline",
            "Recommendation v0 · Eval harness · Baseline metrics",
            "Reliability PASS · Fairness PASS · Intelligence layer: GO",
        ]
    }
    import pandas as pd
    df = pd.DataFrame(sprint_data)
    st.dataframe(df, use_container_width=True, hide_index=True, height=280)

    st.markdown("<br/>", unsafe_allow_html=True)

    col1, col2, col3 = st.columns([1, 2, 1])
    with col2:
        st.markdown("""
        <div style='text-align:center; margin-bottom:12px;'>
          <div style='font-size:14px; color:#7070A8;'>Ready to begin?</div>
        </div>
        """, unsafe_allow_html=True)
        if st.button("🚀  Start Assessment Journey", use_container_width=True, type="primary"):
            st.session_state["page"] = "login"
            st.rerun()

        st.markdown("""
        <div style='text-align:center; margin-top:10px;'>
          <div style='font-size:12px; color:#4040A0;'>
            Complete journey: Login → Identity → Assessment → Results → Career Match
          </div>
        </div>
        """, unsafe_allow_html=True)