import streamlit as st
import time
from core.ui import page_header, inject_css, theta_chart
from core.engine import (
    ensure_engines, start_cat_session, fetch_next_item,
    submit_response, process_proctoring_frame,
)


OPTION_LABELS = ["A", "B", "C", "D"]


def _difficulty_color(band: str) -> str:
    return {"Easy": "#34D399", "Medium": "#FCD34D", "Hard": "#F87171"}.get(band, "#9090C0")


def _bloom_icon(level: str) -> str:
    return {
        "Remember": "💭", "Understand": "🔍", "Apply": "⚙️",
        "Analyze": "🔬", "Evaluate": "⚖️", "Create": "🛠️",
    }.get(level, "📌")


def render():
    inject_css()

    if not st.session_state.get("student_id"):
        st.warning("Please log in first.")
        if st.button("Go to Login"):
            st.session_state["page"] = "login"
            st.rerun()
        return

    engines = ensure_engines(st)
    page_header(
        "Adaptive Assessment",
        f"Competency: {st.session_state.get('competency_id')} · Student: {st.session_state.get('student_name')}",
        "📝"
    )

    if st.session_state.get("cat_finished"):
        final = st.session_state.get("final_score", {})
        st.markdown("""
        <div class='pm-card-accent' style='text-align:center; padding:2rem;'>
          <div style='font-size:36px; margin-bottom:8px;'>🎉</div>
          <div style='font-size:20px; font-weight:700; color:#E8E8F8; margin-bottom:4px;'>Assessment Complete!</div>
          <div style='font-size:14px; color:#7070A8;'>Your responses have been recorded and scored.</div>
        </div>
        """, unsafe_allow_html=True)

        if final:
            c1, c2, c3, c4 = st.columns(4)
            c1.metric("Scaled Score", final.get("scaled_score", "—"))
            c2.metric("Performance Band", final.get("performance_band", "—"))
            c3.metric("Ability (θ)", f"{final.get('ability_estimate', 0):.3f}")
            c4.metric("SEM", f"{final.get('sem', 0):.4f}")

        col1, col2 = st.columns(2)
        with col1:
            if st.button("📊  View Full Results", type="primary", use_container_width=True):
                st.session_state["page"] = "results"
                st.rerun()
        with col2:
            if st.button("💼  Career Recommendations", use_container_width=True):
                st.session_state["page"] = "recommendations"
                st.rerun()
        return

    if not st.session_state.get("cat_started"):
        _show_instructions(engines)
        return

    _show_active_assessment(engines)


def _show_instructions(engines):
    st.markdown("""
    <div class='pm-card-accent'>
      <div style='font-size:16px; font-weight:600; color:#E8E8F8; margin-bottom:12px;'>
        📋 Before You Begin
      </div>
      <div style='font-size:13px; color:#9090C0; line-height:1.8;'>
        This assessment uses <b style='color:#A78BFA;'>Computer Adaptive Testing (CAT)</b> powered by
        the 3-Parameter Logistic IRT model. Questions adapt to your ability level in real-time.
      </div>
    </div>
    """, unsafe_allow_html=True)

    col1, col2 = st.columns(2)
    with col1:
        st.markdown("""
        <div class='pm-card'>
          <div style='font-size:13px; color:#A78BFA; font-weight:600; margin-bottom:10px;'>How it works</div>
        """, unsafe_allow_html=True)
        rules = [
            ("🔄", "Questions adapt based on your responses"),
            ("📈", "Correct answer → harder next question"),
            ("📉", "Wrong answer → adjusted difficulty"),
            ("🎯", "Test ends when SEM ≤ 0.30 OR max 20 items"),
            ("⚡", "Minimum 5 items before stopping"),
            ("🔒", "Proctoring is active throughout"),
        ]
        for icon, text in rules:
            st.markdown(f"<div style='font-size:12px; color:#9090C0; padding:4px 0;'>{icon} {text}</div>", unsafe_allow_html=True)
        st.markdown("</div>", unsafe_allow_html=True)

    with col2:
        st.markdown("""
        <div class='pm-card'>
          <div style='font-size:13px; color:#A78BFA; font-weight:600; margin-bottom:10px;'>IRT Parameters</div>
        """, unsafe_allow_html=True)
        params = [
            ("Model", "3PL (Three-Parameter Logistic)"),
            ("a parameter", "Discrimination (0.5–2.5)"),
            ("b parameter", "Difficulty (logit scale)"),
            ("c parameter", "Guessing (MCQ: 0.20, Coding: 0.0)"),
            ("Stopping SEM", "≤ 0.30"),
            ("Max Items", "20"),
        ]
        for label, val in params:
            st.markdown(f"""
            <div style='display:flex; justify-content:space-between; padding:4px 0;
                        border-bottom:1px solid #2D2D55; font-size:12px;'>
              <span style='color:#7070A8;'>{label}</span>
              <span style='color:#E8E8F8; font-weight:500;'>{val}</span>
            </div>
            """, unsafe_allow_html=True)
        st.markdown("</div>", unsafe_allow_html=True)

    st.markdown("<br/>", unsafe_allow_html=True)
    col_c, col_btn, col_c2 = st.columns([1, 2, 1])
    with col_btn:
        if st.button("▶  Start Adaptive Assessment", type="primary", use_container_width=True):
            start_cat_session(st.session_state, engines)
            if st.session_state.get("proctoring_started"):
                process_proctoring_frame(
    st.session_state,
    engines,
    frame_bytes=None,
    scenario="clean"
)
            st.rerun()


def _show_active_assessment(engines):

    if not st.session_state.get("current_item"):
        with st.spinner("Selecting next question..."):
            item = fetch_next_item(st.session_state, engines)
        if item is None:
            st.rerun()
            return
    else:
        item = st.session_state["current_item"]

    item_data = item.get("item_data", {})
    item_count = st.session_state["item_count"]

    prog_col, stat_col1, stat_col2, stat_col3 = st.columns([3, 1, 1, 1])
    with prog_col:
        progress_val = min(1.0, item_count / 20)
        st.progress(progress_val)
        st.markdown(f"<div style='font-size:11px; color:#6060A0;'>Item {item_count + 1} / 20 max</div>", unsafe_allow_html=True)
    with stat_col1:
        st.metric("Items Done", item_count)
    with stat_col2:
        theta = round(st.session_state["current_theta"], 3)
        st.metric("Ability θ", theta)
    with stat_col3:
        sem = round(st.session_state["current_sem"], 3)
        st.metric("SEM", sem)

    st.markdown("<br/>", unsafe_allow_html=True)

    q_col, info_col = st.columns([3, 1])

    with q_col:
        
        diff_band = item_data.get("difficulty_band", item.get("difficulty_band", "Medium"))
        bloom = item_data.get("bloom_level", "—") if item_data else "—"
        item_type = item_data.get("item_type", "MCQ") if item_data else "MCQ"
        diff_color = _difficulty_color(diff_band)

        st.markdown(f"""
        <div style='display:flex; gap:10px; margin-bottom:12px; flex-wrap:wrap;'>
          <span style='background:#1A1A30; border:1px solid {diff_color}; color:{diff_color};
                       border-radius:6px; padding:3px 10px; font-size:11px; font-weight:600;'>
            {diff_band}
          </span>
          <span style='background:#1A1A30; border:1px solid #3D3D70; color:#9090C0;
                       border-radius:6px; padding:3px 10px; font-size:11px;'>
            {_bloom_icon(bloom)} {bloom}
          </span>
          <span style='background:#1A1A30; border:1px solid #3D3D70; color:#9090C0;
                       border-radius:6px; padding:3px 10px; font-size:11px;'>
            {item_type}
          </span>
          <span style='background:#1A1A30; border:1px solid #3D3D70; color:#6060A0;
                       border-radius:6px; padding:3px 10px; font-size:11px; font-family:monospace;'>
            {item.get("item_id", "")}
          </span>
        </div>
        """, unsafe_allow_html=True)

        
        question_text = item_data.get("question_text", "Question unavailable") if item_data else "Question unavailable"
        st.markdown(f"""
        <div class='pm-card' style='padding:1.5rem;'>
          <div style='font-size:11px; color:#6060A0; text-transform:uppercase;
                      letter-spacing:0.08em; margin-bottom:10px;'>Question</div>
          <div style='font-size:16px; color:#E8E8F8; line-height:1.7; font-weight:400;'>
            {question_text}
          </div>
        </div>
        """, unsafe_allow_html=True)

        
        if item_type == "MCQ" and item_data and item_data.get("options"):
            options = item_data["options"]
            answer_key = item_data.get("answer_key", "A")

            st.markdown("<div style='margin-top:12px;'>", unsafe_allow_html=True)
            selected = st.radio(
                "Select your answer:",
                list(options.keys()),
                format_func=lambda k: f"({k})  {options[k]}",
                key=f"answer_{item.get('item_id')}",
                label_visibility="collapsed",
            )
            st.markdown("</div>", unsafe_allow_html=True)

            col_sub, col_skip = st.columns([3, 1])
            with col_sub:
                if st.button("✓  Submit Answer", type="primary", use_container_width=True):
                    response = 1 if selected == answer_key else 0
                    _handle_submission(engines, response)
            with col_skip:
                if st.button("Skip →", use_container_width=True):
                    _handle_submission(engines, 0)

        elif item_type in ("Coding", "Numeric"):
            if item_type == "Numeric":
                user_answer = st.number_input(
                    "Your numeric answer:",
                    key=f"num_{item.get('item_id')}",
                    step=1,
                )
                correct_ans = item_data.get("answer_key", "0") if item_data else "0"
                try:
                    is_correct = abs(float(user_answer) - float(correct_ans)) < 0.01
                except:
                    is_correct = False
            else:
                user_answer = st.text_area(
                    "Write your code solution:",
                    height=150,
                    key=f"code_{item.get('item_id')}",
                    placeholder="# Write your solution here\n",
                )
                
                is_correct = len(user_answer.strip()) > 10

            if st.button("✓  Submit", type="primary", use_container_width=True):
                _handle_submission(engines, 1 if is_correct else 0)
        else:
            
            c1, c2 = st.columns(2)
            with c1:
                if st.button("✓ Mark Correct", type="primary", use_container_width=True):
                    _handle_submission(engines, 1)
            with c2:
                if st.button("✗ Mark Incorrect", use_container_width=True):
                    _handle_submission(engines, 0)

       
        reason = item.get("reason", "")
        if reason and item_count > 0:
            st.markdown(f"""
            <div style='margin-top:12px; padding:10px 14px; background:#111128;
                        border-left:3px solid #6C3FC5; border-radius:0 8px 8px 0;
                        font-size:12px; color:#7070A8;'>
              🧠 <i>{reason}</i>
            </div>
            """, unsafe_allow_html=True)

    with info_col:
        
        st.markdown("### 📹 Proctoring Camera")
        img_file = st.camera_input(
            "Live Exam Monitoring",
            key="assessment_camera")
        if img_file is not None:
            frame_bytes = img_file.getvalue()
            st.session_state["assessment_frame"] = frame_bytes
            result = process_proctoring_frame(
                st.session_state,engines,frame_bytes=frame_bytes,scenario="clean")
            
        st.markdown("<div style='font-size:12px; color:#A78BFA; font-weight:600; margin-bottom:6px;'>Ability Estimate θ</div>", unsafe_allow_html=True)
        theta_chart(st.session_state.get("theta_history", []))

        
        st.markdown("<div style='font-size:12px; color:#A78BFA; font-weight:600; margin:12px 0 6px;'>Precision (SEM)</div>", unsafe_allow_html=True)
        sem_val = st.session_state["current_sem"]
        sem_pct = max(0, min(100, int((1 - sem_val / 1.5) * 100)))
        sem_color = "#34D399" if sem_val <= 0.30 else "#FCD34D" if sem_val <= 0.60 else "#F87171"
        st.markdown(f"""
        <div style='font-size:22px; font-weight:700; color:{sem_color};'>{sem_val:.4f}</div>
        <div style='background:#0F0F1A; border-radius:6px; height:6px; margin:6px 0;'>
          <div style='height:100%; width:{sem_pct}%; background:{sem_color}; border-radius:6px;'></div>
        </div>
        <div style='font-size:11px; color:#5050A0;'>Target: ≤ 0.30</div>
        """, unsafe_allow_html=True)

        
        st.markdown("<div style='font-size:12px; color:#A78BFA; font-weight:600; margin:16px 0 6px;'>Proctoring</div>", unsafe_allow_html=True)
        risk = st.session_state.get("risk_score", 0.0)
        risk_color = "#34D399" if risk <= 0.30 else "#FCD34D" if risk <= 0.70 else "#F87171"
        status = st.session_state.get("integrity_status", "PASS")
        st.markdown(f"""
        <div style='background:#1A1A30; border:1px solid #2D2D55; border-radius:8px; padding:10px;'>
          <div style='font-size:20px; font-weight:700; color:{risk_color};'>{int(risk*100)}%</div>
          <div style='font-size:11px; color:#6060A0; margin-top:2px;'>Risk · {status}</div>
        </div>
        """, unsafe_allow_html=True)

        violations = st.session_state.get("violations", [])
        if violations:
            st.markdown(f"<div style='font-size:11px; color:#F87171; margin-top:6px;'>⚠ {len(violations)} violation(s)</div>", unsafe_allow_html=True)

    history = st.session_state.get("item_history", [])
    if history:
        with st.expander(f"📋 Item History ({len(history)} answered)", expanded=False):
            for i, h in enumerate(reversed(history[-10:])):
                resp_icon = "✓" if h["response"] == 1 else "✗"
                resp_color = "#34D399" if h["response"] == 1 else "#F87171"
                st.markdown(f"""
                <div style='display:flex; gap:12px; padding:8px 0; border-bottom:1px solid #1A1A30;
                            font-size:12px; align-items:center;'>
                  <span style='color:{resp_color}; font-weight:700; width:16px;'>{resp_icon}</span>
                  <span style='color:#7070A8; width:60px;'>{h["difficulty"]}</span>
                  <span style='color:#E8E8F8; flex:1;'>{h["question"][:80]}...</span>
                  <span style='color:#A78BFA; font-family:monospace; width:60px;'>θ={h["theta"]:.3f}</span>
                </div>
                """, unsafe_allow_html=True)


def _handle_submission(engines, response: int):
    
    result = submit_response(st.session_state, engines, response)
    
    if st.session_state.get("proctoring_started"):
        process_proctoring_frame(st.session_state, engines, scenario="clean")
    
    st.session_state["current_item"] = None
    st.rerun()