
import streamlit as st
import math
from core.ui import page_header, inject_css, performance_pill, theta_chart
from core.engine import ensure_engines, generate_recommendations


def render():
    inject_css()

    if not st.session_state.get("student_id"):
        st.warning("Please log in first.")
        if st.button("Go to Login"):
            st.session_state["page"] = "login"
            st.rerun()
        return

    engines = ensure_engines(st)
    page_header("Assessment Results", "Your IRT-calibrated performance report", "📊")

    final = st.session_state.get("final_score")

    if not final:
        if not st.session_state.get("cat_finished"):
            st.info("Complete the assessment first to see your results.")
            if st.button("▶  Go to Assessment"):
                st.session_state["page"] = "assessment"
                st.rerun()
        else:
            st.warning("Results not yet computed.")
        return

    student_name = st.session_state.get("student_name", "Student")
    student_id = st.session_state.get("student_id", "")
    competency = st.session_state.get("competency_id", "")
    assessment_id = st.session_state.get("assessment_id", "")

    scaled = final.get("scaled_score", 500)
    band = final.get("performance_band", "Average")
    theta = final.get("ability_estimate", 0.0)
    sem = final.get("sem", 0.3)
    n_items = final.get("n_items_administered", 0)
    stop_reason = final.get("stop_reason", "")

    band_configs = {
        "Excellent": ("#7C3AED", "#EDE9FE", "🏆"),
        "Good": ("#0891B2", "#E0F2FE", "🥇"),
        "Average": ("#D97706", "#FEF3C7", "📈"),
        "Beginner": ("#6B7280", "#F3F4F6", "📚"),
    }
    band_color, band_bg, band_icon = band_configs.get(band, ("#6B7280", "#F3F4F6", "📌"))

    st.markdown(f"""
    <div style='background:linear-gradient(135deg, #1E1040 0%, #1A1A30 100%);
                border:1px solid #5B3EC4; border-radius:20px; padding:2rem;
                text-align:center; margin-bottom:1.5rem;'>
      <div style='font-size:11px; color:#7070A8; text-transform:uppercase;
                  letter-spacing:0.1em; margin-bottom:8px;'>Assessment Complete</div>
      <div style='font-size:13px; color:#9090C0; margin-bottom:12px;'>
        {student_name} · {student_id} · {competency}
      </div>
      <div style='font-size:72px; font-weight:700; color:#E8E8F8; line-height:1;
                  margin-bottom:8px;'>{scaled}</div>
      <div style='font-size:14px; color:#7070A8; margin-bottom:16px;'>Scaled Score (100–900)</div>
      <span style='background:{band_color}; color:white; border-radius:24px;
                   padding:8px 24px; font-size:16px; font-weight:600;'>
        {band_icon} {band}
      </span>
    </div>
    """, unsafe_allow_html=True)

    c1, c2, c3, c4, c5 = st.columns(5)
    c1.metric("Ability θ", f"{theta:.4f}", help="Student ability on the logit scale")
    c2.metric("SEM", f"{sem:.4f}", help="Standard Error of Measurement")
    c3.metric("Items Used", n_items, help="Questions administered")
    c4.metric("Percentile (est.)", _theta_to_percentile(theta), help="Estimated percentile")
    c5.metric("Stop Reason", stop_reason.replace("_", " ").title()[:12] if stop_reason else "—")

    st.markdown("<br/>", unsafe_allow_html=True)

    col_left, col_right = st.columns([3, 2])

    with col_left:
        st.markdown("<div style='font-size:13px; color:#A78BFA; font-weight:600; margin-bottom:8px;'>Ability Estimate Evolution</div>", unsafe_allow_html=True)
        theta_hist = st.session_state.get("theta_history", [])
        if theta_hist:
            theta_chart(theta_hist)
        else:
            st.info("No history available.")

        history = st.session_state.get("item_history", [])
        if history:
            st.markdown("<br/>", unsafe_allow_html=True)
            st.markdown("<div style='font-size:13px; color:#A78BFA; font-weight:600; margin-bottom:8px;'>Item Response Log</div>", unsafe_allow_html=True)
            import pandas as pd
            rows = []
            for i, h in enumerate(history):
                rows.append({
                    "#": i + 1,
                    "Difficulty": h["difficulty"],
                    "Response": "✓ Correct" if h["response"] == 1 else "✗ Wrong",
                    "θ After": f"{h['theta']:.4f}",
                    "SEM After": f"{h['sem']:.4f}",
                })
            df = pd.DataFrame(rows)
            st.dataframe(df, use_container_width=True, hide_index=True)

    with col_right:
        st.markdown("""
        <div class='pm-card'>
          <div style='font-size:13px; color:#A78BFA; font-weight:600; margin-bottom:12px;'>
            IRT Score Details
          </div>
        """, unsafe_allow_html=True)

        detail_rows = [
            ("Model", "3PL (Three-Parameter Logistic)"),
            ("Estimation", "Maximum Likelihood (MLE)"),
            ("Ability θ", f"{theta:.4f}"),
            ("SEM", f"{sem:.4f}"),
            ("95% CI", f"[{theta - 1.96*sem:.3f}, {theta + 1.96*sem:.3f}]"),
            ("Scaled Score", str(scaled)),
            ("Performance Band", band),
            ("Items Administered", str(n_items)),
            ("Stopping Rule", stop_reason.replace("_", " ").title() if stop_reason else "—"),
        ]
        for label, val in detail_rows:
            st.markdown(f"""
            <div style='display:flex; justify-content:space-between; padding:7px 0;
                        border-bottom:1px solid #1A1A30; font-size:12px;'>
              <span style='color:#7070A8;'>{label}</span>
              <span style='color:#E8E8F8; font-weight:500; font-family:monospace;'>{val}</span>
            </div>
            """, unsafe_allow_html=True)
        st.markdown("</div>", unsafe_allow_html=True)

        st.markdown("""
        <div class='pm-card' style='margin-top:12px;'>
          <div style='font-size:12px; color:#A78BFA; font-weight:600; margin-bottom:10px;'>
            Score Scale (100–900)
          </div>
        """, unsafe_allow_html=True)

        bands = [
            ("Beginner", 100, 400, "#6B7280"),
            ("Average", 400, 600, "#D97706"),
            ("Good", 600, 750, "#0891B2"),
            ("Excellent", 750, 900, "#7C3AED"),
        ]
        for b_name, b_min, b_max, b_color in bands:
            is_current = b_name == band
            b_width = int((b_max - b_min) / 800 * 100)
            border = "3px" if is_current else "1px"
            opacity = "1" if is_current else "0.5"
            st.markdown(f"""
            <div style='margin-bottom:4px;'>
              <div style='display:flex; justify-content:space-between; font-size:10px;
                          color:{"#E8E8F8" if is_current else "#6060A0"}; margin-bottom:2px;'>
                <span style='font-weight:{"700" if is_current else "400"};'>{b_name}</span>
                <span>{b_min}–{b_max}</span>
              </div>
              <div style='background:#0F0F1A; border-radius:4px; height:8px;'>
                <div style='height:100%; width:{b_width}%; background:{b_color};
                            opacity:{opacity}; border-radius:4px;
                            {"box-shadow:0 0 8px " + b_color if is_current else ""}'></div>
              </div>
            </div>
            """, unsafe_allow_html=True)
        st.markdown("</div>", unsafe_allow_html=True)

    st.markdown("<br/>", unsafe_allow_html=True)
    col1, col2, col3 = st.columns([1, 2, 1])
    with col2:
        if st.button("💼  Generate Career Recommendations", type="primary", use_container_width=True):
            with st.spinner("Running recommendation engine..."):
                recs = generate_recommendations(st.session_state, engines)
            st.success(f"Generated {len(recs)} role recommendations!")
            st.session_state["page"] = "recommendations"
            st.rerun()


def _theta_to_percentile(theta: float) -> str:
    
    z = theta  
    
    pct = int(100 * (0.5 * (1 + math.erf(z / math.sqrt(2)))))
    pct = max(1, min(99, pct))
    return f"{pct}th"