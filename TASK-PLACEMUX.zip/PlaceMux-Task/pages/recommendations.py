
import streamlit as st
from core.ui import page_header, inject_css
from core.engine import ensure_engines, generate_recommendations


COMPANY_LOGOS = {
    "Flipkart": "🛒", "Razorpay": "💳", "Zepto": "⚡", "Meesho": "🛍️",
    "Google": "🔍", "Microsoft": "💻", "Amazon": "📦", "Atlassian": "🔷",
    "Sarvam AI": "🧠", "Krutrim": "🤖",
    "Freshworks": "🌟", "Zoho": "☁️", "Chargebee": "💰", "Postman": "📮",
    "Accenture": "🏢", "Infosys Cloud": "🔵", "TCS iON": "🏗️", "HCL": "💼",
    "Oracle India": "🔴", "SAP Labs": "🔶", "IBM India": "🔷",
    "Texas Instruments": "🔬", "Bosch India": "⚙️", "Qualcomm India": "📡",
    "Qualcomm": "📡", "MediaTek": "🔌", "Intel India": "🖥️", "NXP": "🔧",
}


def _match_color(pct: int) -> str:
    if pct >= 70:
        return "#34D399"
    elif pct >= 50:
        return "#FCD34D"
    else:
        return "#9090C0"


def _gap_status_badge(status: str, score, required) -> str:
    if status == "MET":
        surplus = score - required if score and required else 0
        return f"<span style='color:#34D399; font-size:11px; font-weight:600;'>✓ Met (+{surplus})</span>"
    elif status == "GAP":
        gap = required - score if score and required else 0
        return f"<span style='color:#F87171; font-size:11px; font-weight:600;'>✗ Gap (-{gap})</span>"
    else:
        return f"<span style='color:#7070A8; font-size:11px;'>○ Not assessed</span>"


def render():
    inject_css()

    if not st.session_state.get("student_id"):
        st.warning("Please log in first.")
        if st.button("Go to Login"):
            st.session_state["page"] = "login"
            st.rerun()
        return

    engines = ensure_engines(st)
    page_header(
        "Career Recommendations",
        f"Skill-matched roles for {st.session_state.get('student_name')}",
        "💼"
    )

    recs = st.session_state.get("recommendations", [])

    if not recs:
        if not st.session_state.get("final_score"):
            st.info("Complete the assessment to unlock career recommendations.")
            if st.button("▶  Go to Assessment"):
                st.session_state["page"] = "assessment"
                st.rerun()
            return

        with st.spinner("Running recommendation engine (Day 6)..."):
            recs = generate_recommendations(st.session_state, engines)

    if not recs:
        st.warning("No recommendations available. Complete more assessments.")
        return

    final = st.session_state.get("final_score", {})
    competency = st.session_state.get("competency_id", "")
    scaled = final.get("scaled_score", 0)
    band = final.get("performance_band", "—")
    theta = final.get("ability_estimate", 0)

    st.markdown(f"""
    <div class='pm-card-accent' style='display:flex; justify-content:space-between; align-items:center;'>
      <div>
        <div style='font-size:11px; color:#7070A8; text-transform:uppercase; letter-spacing:0.08em;'>Assessed Skill Vector</div>
        <div style='font-size:14px; font-weight:600; color:#E8E8F8; margin-top:4px;'>{competency}</div>
        <div style='font-size:12px; color:#9090C0; margin-top:2px;'>Score: {scaled} · {band} · θ={theta:.3f}</div>
      </div>
      <div style='text-align:right;'>
        <div style='font-size:11px; color:#7070A8; text-transform:uppercase; letter-spacing:0.08em;'>Roles matched</div>
        <div style='font-size:28px; font-weight:700; color:#A78BFA;'>{len(recs)}</div>
      </div>
    </div>
    """, unsafe_allow_html=True)

    st.markdown("<br/>", unsafe_allow_html=True)

    top = recs[0]
    top_pct = top.get("match_percentage", 0)
    top_color = _match_color(top_pct)

    st.markdown(f"""
    <div style='background:linear-gradient(135deg, #1E1040 0%, #1A1A30 100%);
                border:2px solid #5B3EC4; border-radius:16px; padding:1.5rem; margin-bottom:1.5rem;'>
      <div style='font-size:11px; color:#7070A8; text-transform:uppercase; letter-spacing:0.1em; margin-bottom:6px;'>
        🏆 Top Match
      </div>
      <div style='display:flex; justify-content:space-between; align-items:flex-start;'>
        <div>
          <div style='font-size:20px; font-weight:700; color:#E8E8F8;'>{top.get("title")}</div>
          <div style='font-size:13px; color:#7070A8; margin-top:4px;'>{top.get("description","")}</div>
          <div style='margin-top:10px; font-size:12px; color:#9090C0; line-height:1.6;'>
            <b style='color:#A78BFA;'>Why this match:</b><br/>{top.get("why_this_match","")}
          </div>
        </div>
        <div style='text-align:center; flex-shrink:0; margin-left:20px;'>
          <div style='font-size:48px; font-weight:700; color:{top_color};'>{top_pct}%</div>
          <div style='font-size:11px; color:#6060A0;'>match score</div>
        </div>
      </div>
      <div style='margin-top:12px; display:flex; gap:8px; flex-wrap:wrap;'>
        {"".join([f'<span style="background:#2D1F5E; color:#A78BFA; border-radius:6px; padding:3px 10px; font-size:12px;">{COMPANY_LOGOS.get(c,"🏢")} {c}</span>' for c in top.get("typical_companies",[])])}
      </div>
    </div>
    """, unsafe_allow_html=True)

    for i, rec in enumerate(recs):
        pct = rec.get("match_percentage", 0)
        color = _match_color(pct)
        title = rec.get("title", "")
        desc = rec.get("description", "")
        why = rec.get("why_this_match", "")
        companies = rec.get("typical_companies", [])
        score_gap = rec.get("score_gap", {})

        with st.expander(f"{'🥇' if i==0 else '🥈' if i==1 else '🥉' if i==2 else '  '} #{i+1}  {title}  —  {pct}% match", expanded=(i < 3)):
            col_main, col_gap = st.columns([3, 2])

            with col_main:
                
                st.markdown(f"""
                <div style='display:flex; align-items:center; gap:12px; margin-bottom:12px;'>
                  <div style='font-size:32px; font-weight:700; color:{color};'>{pct}%</div>
                  <div style='flex:1; background:#0F0F1A; border-radius:6px; height:8px;'>
                    <div style='height:100%; width:{pct}%; background:{color}; border-radius:6px;'></div>
                  </div>
                </div>
                """, unsafe_allow_html=True)

                st.markdown(f"<div style='font-size:13px; color:#9090C0; line-height:1.5; margin-bottom:10px;'>{desc}</div>", unsafe_allow_html=True)

                
                st.markdown(f"""
                <div style='background:#111128; border-left:3px solid #6C3FC5; border-radius:0 8px 8px 0;
                            padding:10px 14px; margin-bottom:10px;'>
                  <div style='font-size:11px; color:#A78BFA; text-transform:uppercase;
                              letter-spacing:0.06em; margin-bottom:4px;'>Why this match</div>
                  <div style='font-size:12px; color:#9090C0; line-height:1.5;'>{why}</div>
                </div>
                """, unsafe_allow_html=True)

                
                if companies:
                    company_html = "".join([
                        f'<span style="background:#1A1A30; border:1px solid #2D2D55; color:#9090C0; border-radius:6px; padding:3px 8px; font-size:11px; margin:2px;">{COMPANY_LOGOS.get(c,"🏢")} {c}</span>'
                        for c in companies
                    ])
                    st.markdown(f"<div style='display:flex; flex-wrap:wrap; gap:4px;'>{company_html}</div>", unsafe_allow_html=True)

            with col_gap:
                st.markdown("""
                <div style='font-size:12px; color:#A78BFA; font-weight:600; margin-bottom:8px;'>
                  Competency Gap Analysis
                </div>
                """, unsafe_allow_html=True)

                if score_gap:
                    for comp_id, detail in score_gap.items():
                        status = detail.get("status", "NOT_ASSESSED")
                        score = detail.get("score")
                        required = detail.get("required", 0)
                        badge_html = _gap_status_badge(status, score, required)
                        score_display = str(score) if score else "—"
                        st.markdown(f"""
                        <div style='background:#111128; border-radius:8px; padding:8px 10px; margin-bottom:6px;'>
                          <div style='display:flex; justify-content:space-between; align-items:center;'>
                            <div style='font-size:11px; font-weight:600; color:#E8E8F8; font-family:monospace;'>{comp_id}</div>
                            {badge_html}
                          </div>
                          <div style='font-size:10px; color:#5050A0; margin-top:3px;'>
                            Scored: {score_display} / Required: ≥{required}
                          </div>
                        </div>
                        """, unsafe_allow_html=True)
                else:
                    st.markdown("<div style='font-size:12px; color:#5050A0;'>No detailed gap data available.</div>", unsafe_allow_html=True)

    with st.expander("ℹ️  How recommendations are calculated"):
        st.markdown("""
        <div style='font-size:13px; color:#9090C0; line-height:1.7;'>

        **Algorithm (Day 6 RecommendationEngine)**

        The scoring formula for each role:
        ```
        match_score = 0.60 × coverage + 0.40 × quality
        ```

        - **Coverage** (60%): Fraction of required competencies where the student meets the minimum scaled score threshold.
          Unassessed competencies count as 0.5 (neutral — unknown, not failed).
        - **Quality** (40%): Average normalized score across assessed competencies, scaled from [100, 900] to [0, 1].
        - **Filter**: Roles with coverage < 0.40 are excluded entirely.
        - **Why-match text**: Programmatically generated from gap analysis and score comparison.
        - **Phase 2**: Will add vector similarity, NLP matching against job descriptions, and A/B tested ranking.
        </div>
        """, unsafe_allow_html=True)