import streamlit as st

from core.engine import init_state, ensure_engines
from core.ui import inject_css, sidebar_nav

from pages import (
    home,
    login,
    assessment,
    proctoring,
    results,
    recommendations,
)

st.set_page_config(
    page_title="PlaceMux",
    page_icon="🎓",
    layout="wide",
    initial_sidebar_state="expanded",
)

init_state(st)

ensure_engines(st)

inject_css()

sidebar_nav()

current_page = st.session_state.get("page", "home")

PAGE_MAP = {
    "home": home.render,
    "login": login.render,
    "assessment": assessment.render,
    "proctoring": proctoring.render,
    "results": results.render,
    "recommendations": recommendations.render,
}

if current_page not in PAGE_MAP:
    st.session_state["page"] = "home"
    current_page = "home"

PAGE_MAP[current_page]()

st.markdown(
    """
    <hr style="border:none; border-top:1px solid #2D2D55; margin-top:2rem;">
    <div style="text-align:center; padding:1rem 0;">
        <div style="font-size:12px; color:#6060A0;">
            PlaceMux — AI-Powered Adaptive Assessment Platform
        </div>
        <div style="font-size:11px; color:#404080; margin-top:4px;">
            Day 2: IRT Calibration · Day 3: CAT Engine ·
            Day 4: Proctoring · Day 5: Integration ·
            Day 6: Recommendations · Day 7: Validation
        </div>
    </div>
    """,
    unsafe_allow_html=True,
)